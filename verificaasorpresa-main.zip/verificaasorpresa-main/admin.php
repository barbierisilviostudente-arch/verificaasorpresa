<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>Admin Dashboard — Catalogo Fornitori</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet"/>
<style>
:root{
  --bg:#0a0b0d;--surface:#111316;--card:#161a1e;--border:#1f2428;--border2:#252b30;
  --accent:#00c98d;--accent2:#0099ff;--accent3:#ff6b35;--danger:#ff4757;
  --text:#e8edf2;--muted:#5a6470;--muted2:#8a95a0;
  --font:"Space Grotesk",sans-serif;--mono:"JetBrains Mono",monospace;
}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:var(--font);background:var(--bg);color:var(--text);min-height:100vh;display:flex}
#login-screen{position:fixed;inset:0;background:var(--bg);display:flex;align-items:center;justify-content:center;z-index:9999}
.login-box{background:var(--card);border:1px solid var(--border2);border-radius:16px;padding:48px 40px;width:380px;text-align:center}
.login-box .logo{font-size:2rem;margin-bottom:8px}
.login-box h1{font-size:1.4rem;font-weight:700;margin-bottom:4px}
.login-box p{color:var(--muted2);font-size:0.85rem;margin-bottom:32px}
.input-group{margin-bottom:14px;text-align:left}
.input-group label{display:block;font-size:0.78rem;font-weight:600;color:var(--muted2);margin-bottom:6px;text-transform:uppercase;letter-spacing:.06em}
.input-group input{width:100%;background:#0e1114;border:1px solid var(--border2);border-radius:8px;padding:11px 14px;color:var(--text);font-family:var(--font);font-size:0.9rem;outline:none;transition:border-color .2s}
.input-group input:focus{border-color:var(--accent)}
.btn-login{width:100%;background:var(--accent);color:#000;font-family:var(--font);font-weight:700;font-size:0.95rem;border:none;border-radius:8px;padding:13px;cursor:pointer;margin-top:8px;transition:opacity .2s}
.btn-login:hover{opacity:.85}
.login-error{color:var(--danger);font-size:0.82rem;margin-top:10px;display:none}
#sidebar{width:240px;background:var(--surface);border-right:1px solid var(--border);position:fixed;top:0;left:0;height:100vh;display:flex;flex-direction:column;z-index:100}
.sb-logo{padding:24px 20px 18px;border-bottom:1px solid var(--border)}
.sb-logo .badge{font-size:.65rem;background:var(--accent);color:#000;padding:2px 7px;border-radius:20px;font-weight:700;margin-bottom:6px;display:inline-block}
.sb-logo h2{font-size:1rem;font-weight:700}
.sb-nav{flex:1;padding:12px 0;overflow-y:auto}
.sb-section{padding:10px 20px 4px;font-size:.65rem;font-weight:700;letter-spacing:.1em;color:var(--muted);text-transform:uppercase}
.sb-nav a{display:flex;align-items:center;gap:10px;padding:9px 20px;color:var(--muted2);text-decoration:none;font-size:.85rem;font-weight:500;border-left:2px solid transparent;transition:all .15s}
.sb-nav a:hover{color:var(--text);background:rgba(255,255,255,.04)}
.sb-nav a.active{color:var(--accent);border-left-color:var(--accent);background:rgba(0,201,141,.07)}
.sb-nav a .ico{width:16px;text-align:center;font-size:.9rem}
.sb-foot{padding:16px 20px;border-top:1px solid var(--border)}
.sb-user{font-size:.8rem;color:var(--muted2);margin-bottom:8px}
.sb-user strong{color:var(--text);display:block}
.btn-logout{width:100%;background:transparent;border:1px solid var(--border2);border-radius:6px;color:var(--muted2);padding:7px;font-family:var(--font);font-size:.8rem;cursor:pointer;transition:all .15s}
.btn-logout:hover{border-color:var(--danger);color:var(--danger)}
#main{margin-left:240px;flex:1;padding:0}
.topbar{padding:20px 32px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;background:rgba(10,11,13,.9);backdrop-filter:blur(10px);z-index:50}
.topbar h1{font-size:1.1rem;font-weight:700}
.topbar .crumb{font-size:.78rem;color:var(--muted2);margin-top:2px}
.content{padding:28px 32px}
.stats-row{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:28px}
.stat-card{background:var(--card);border:1px solid var(--border);border-radius:10px;padding:20px;position:relative;overflow:hidden}
.stat-card::before{content:'';position:absolute;top:0;left:0;right:0;height:2px}
.stat-card.c1::before{background:var(--accent)}
.stat-card.c2::before{background:var(--accent2)}
.stat-card.c3::before{background:var(--accent3)}
.stat-card.c4::before{background:#a78bfa}
.stat-card .label{font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--muted2);margin-bottom:8px}
.stat-card .val{font-size:2rem;font-weight:700;font-family:var(--mono)}
.stat-card .sub{font-size:.75rem;color:var(--muted);margin-top:4px}
.table-card{background:var(--card);border:1px solid var(--border);border-radius:10px;overflow:hidden}
.tc-header{padding:18px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:12px;flex-wrap:wrap}
.tc-header h3{font-size:.95rem;font-weight:700;flex:1}
.search-box{background:#0e1114;border:1px solid var(--border2);border-radius:7px;padding:7px 12px;color:var(--text);font-family:var(--font);font-size:.83rem;outline:none;width:200px;transition:border-color .2s}
.search-box:focus{border-color:var(--accent)}
.btn{display:inline-flex;align-items:center;gap:6px;padding:8px 16px;border-radius:7px;font-family:var(--font);font-size:.82rem;font-weight:600;border:none;cursor:pointer;transition:all .15s}
.btn-primary{background:var(--accent);color:#000}
.btn-primary:hover{opacity:.85}
.btn-sm{padding:5px 11px;font-size:.75rem;border-radius:5px}
.btn-edit{background:rgba(0,153,255,.15);color:var(--accent2)}
.btn-edit:hover{background:rgba(0,153,255,.25)}
.btn-del{background:rgba(255,71,87,.12);color:var(--danger)}
.btn-del:hover{background:rgba(255,71,87,.22)}
.btn-view{background:rgba(0,201,141,.1);color:var(--accent)}
.btn-view:hover{background:rgba(0,201,141,.2)}
.btn-secondary{background:var(--border2);color:var(--muted2)}
.btn-secondary:hover{color:var(--text)}
table{width:100%;border-collapse:collapse}
thead th{padding:11px 16px;font-size:.7rem;text-transform:uppercase;letter-spacing:.07em;color:var(--muted);font-weight:700;text-align:left;background:#0e1114;border-bottom:1px solid var(--border)}
tbody tr{border-bottom:1px solid var(--border);transition:background .1s}
tbody tr:last-child{border:none}
tbody tr:hover{background:rgba(255,255,255,.025)}
tbody td{padding:11px 16px;font-size:.87rem}
.tag{display:inline-block;padding:2px 9px;border-radius:20px;font-size:.7rem;font-weight:700}
.tag-red{background:rgba(255,71,87,.15);color:#ff6b7a}
.tag-green{background:rgba(0,201,141,.12);color:var(--accent)}
.tag-blue{background:rgba(0,153,255,.12);color:var(--accent2)}
.tag-yellow{background:rgba(255,213,0,.12);color:#ffd500}
.tag-other{background:rgba(255,255,255,.08);color:var(--muted2)}
.tag-admin{background:rgba(255,107,53,.15);color:var(--accent3)}
.tag-supplier{background:rgba(167,139,250,.12);color:#a78bfa}
.pagination{display:flex;align-items:center;gap:6px;padding:14px 20px;border-top:1px solid var(--border)}
.pagination .info{font-size:.78rem;color:var(--muted2);flex:1}
.page-btn{background:var(--border);border:none;color:var(--muted2);padding:5px 10px;border-radius:5px;cursor:pointer;font-family:var(--mono);font-size:.75rem;transition:all .15s}
.page-btn:hover{color:var(--text);background:var(--border2)}
.page-btn.active{background:var(--accent);color:#000}
.page-btn:disabled{opacity:.3;cursor:not-allowed}
.overlay{position:fixed;inset:0;background:rgba(0,0,0,.7);backdrop-filter:blur(4px);z-index:1000;display:none;align-items:center;justify-content:center}
.overlay.open{display:flex}
.modal-box{background:var(--card);border:1px solid var(--border2);border-radius:14px;width:520px;max-width:95vw;max-height:90vh;overflow:hidden;display:flex;flex-direction:column;animation:slideUp .2s ease}
@keyframes slideUp{from{transform:translateY(20px);opacity:0}to{transform:translateY(0);opacity:1}}
.modal-head{padding:20px 24px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between}
.modal-head h4{font-size:1rem;font-weight:700}
.modal-close{background:none;border:none;color:var(--muted2);font-size:1.3rem;cursor:pointer;line-height:1}
.modal-close:hover{color:var(--danger)}
.modal-body{padding:24px;overflow-y:auto;flex:1}
.modal-foot{padding:16px 24px;border-top:1px solid var(--border);display:flex;gap:10px;justify-content:flex-end}
.form-row{margin-bottom:16px}
.form-row label{display:block;font-size:.75rem;font-weight:700;color:var(--muted2);text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px}
.form-row input,.form-row select{width:100%;background:#0e1114;border:1px solid var(--border2);border-radius:7px;padding:10px 13px;color:var(--text);font-family:var(--font);font-size:.88rem;outline:none;transition:border-color .2s}
.form-row input:focus,.form-row select:focus{border-color:var(--accent)}
.form-row select option{background:var(--card)}
.detail-section{margin-bottom:20px}
.detail-section h5{font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:var(--accent);margin-bottom:12px;padding-bottom:8px;border-bottom:1px solid var(--border)}
.detail-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.detail-item{background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:7px;padding:10px 13px}
.detail-item .dk{font-size:.68rem;text-transform:uppercase;letter-spacing:.08em;color:var(--muted);margin-bottom:3px}
.detail-item .dv{font-size:.9rem;font-weight:600}
.detail-list{list-style:none}
.detail-list li{display:flex;align-items:center;justify-content:space-between;padding:9px 0;border-bottom:1px solid var(--border)}
.detail-list li:last-child{border:none}
.detail-list .cost{font-family:var(--mono);font-size:.82rem;color:var(--accent)}
.empty-row td{text-align:center;padding:48px;color:var(--muted);font-size:.88rem}
.section-tab{display:none}
.section-tab.active{display:block}
.mono{font-family:var(--mono)}
</style>
</head>
<body>

<div id="login-screen">
  <div class="login-box">
    <div class="logo">🔐</div>
    <h1>Admin Dashboard</h1>
    <p>Accedi con le tue credenziali di amministratore</p>
    <div class="input-group"><label>Username</label><input type="text" id="login-user" placeholder="admin" autocomplete="username"/></div>
    <div class="input-group"><label>Password</label><input type="password" id="login-pass" placeholder="••••••••" autocomplete="current-password"/></div>
    <button class="btn-login" onclick="doLogin()">Accedi</button>
    <div class="login-error" id="login-err"></div>
  </div>
</div>

<nav id="sidebar" style="display:none">
  <div class="sb-logo">
    <div class="badge">ADMIN</div>
    <h2>Catalogo DB</h2>
  </div>
  <div class="sb-nav">
    <div class="sb-section">Dashboard</div>
    <a href="#" class="active" onclick="showSection('overview');return false"><span class="ico">📊</span> Panoramica</a>
    <div class="sb-section">Gestione</div>
    <a href="#" onclick="showSection('suppliers');return false"><span class="ico">🏭</span> Fornitori</a>
    <a href="#" onclick="showSection('pieces');return false"><span class="ico">🔩</span> Pezzi</a>
    <a href="#" onclick="showSection('catalog');return false"><span class="ico">📋</span> Catalogo</a>
    <a href="#" onclick="showSection('users');return false"><span class="ico">👥</span> Utenti</a>
    <div class="sb-section">Query</div>
    <a href="index.php"><span class="ico">🔍</span> Catalog Queries</a>
  </div>
  <div class="sb-foot">
    <div class="sb-user"><span>Connesso come</span><strong id="sb-username">—</strong></div>
    <button class="btn-logout" onclick="doLogout()">Disconnetti</button>
  </div>
</nav>

<div id="main" style="display:none">
  <div class="topbar">
    <div><h1 id="top-title">Panoramica</h1><div class="crumb">Dashboard amministratore</div></div>
  </div>
  <div class="content">

    <div class="section-tab active" id="sec-overview">
      <div class="stats-row">
        <div class="stat-card c1"><div class="label">Fornitori</div><div class="val" id="stat-f">—</div><div class="sub">totali nel sistema</div></div>
        <div class="stat-card c2"><div class="label">Pezzi</div><div class="val" id="stat-p">—</div><div class="sub">totali nel catalogo</div></div>
        <div class="stat-card c3"><div class="label">Voci Catalogo</div><div class="val" id="stat-c">—</div><div class="sub">associazioni</div></div>
        <div class="stat-card c4"><div class="label">Utenti</div><div class="val" id="stat-u">—</div><div class="sub">registrati</div></div>
      </div>
      <div style="color:var(--muted2);font-size:.88rem;line-height:1.8;background:var(--card);border:1px solid var(--border);border-radius:10px;padding:24px">
        <strong style="color:var(--text);display:block;margin-bottom:8px">Benvenuto nella dashboard admin</strong>
        Usa il menu a sinistra per gestire fornitori, pezzi, catalogo e utenti.
      </div>
    </div>

    <div class="section-tab" id="sec-suppliers">
      <div class="table-card">
        <div class="tc-header">
          <h3>Fornitori</h3>
          <input class="search-box" type="text" placeholder="Cerca..." id="search-suppliers" oninput="loadSuppliers(1)"/>
          <button class="btn btn-primary btn-sm" onclick="openAddSupplier()">+ Aggiungi</button>
        </div>
        <table><thead><tr><th>ID</th><th>Nome</th><th>Pezzi</th><th>Azioni</th></tr></thead>
        <tbody id="tb-suppliers"><tr class="empty-row"><td colspan="4">Caricamento...</td></tr></tbody></table>
        <div class="pagination" id="pg-suppliers"></div>
      </div>
    </div>

    <div class="section-tab" id="sec-pieces">
      <div class="table-card">
        <div class="tc-header">
          <h3>Pezzi</h3>
          <input class="search-box" type="text" placeholder="Cerca..." id="search-pieces" oninput="loadPieces(1)"/>
          <button class="btn btn-primary btn-sm" onclick="openAddPiece()">+ Aggiungi</button>
        </div>
        <table><thead><tr><th>ID</th><th>Nome</th><th>Colore</th><th>Fornitori</th><th>Azioni</th></tr></thead>
        <tbody id="tb-pieces"><tr class="empty-row"><td colspan="5">Caricamento...</td></tr></tbody></table>
        <div class="pagination" id="pg-pieces"></div>
      </div>
    </div>

    <div class="section-tab" id="sec-catalog">
      <div class="table-card">
        <div class="tc-header">
          <h3>Catalogo</h3>
          <select class="search-box" id="filter-cat-fid" onchange="loadCatalog(1)" style="width:150px"><option value="">Tutti i fornitori</option></select>
          <button class="btn btn-primary btn-sm" onclick="openAddCatalog()">+ Aggiungi</button>
        </div>
        <table><thead><tr><th>Fornitore</th><th>Pezzo</th><th>Colore</th><th>Costo</th><th>Azioni</th></tr></thead>
        <tbody id="tb-catalog"><tr class="empty-row"><td colspan="5">Caricamento...</td></tr></tbody></table>
        <div class="pagination" id="pg-catalog"></div>
      </div>
    </div>

    <div class="section-tab" id="sec-users">
      <div class="table-card">
        <div class="tc-header">
          <h3>Utenti</h3>
          <button class="btn btn-primary btn-sm" onclick="openAddUser()">+ Aggiungi</button>
        </div>
        <table><thead><tr><th>ID</th><th>Username</th><th>Ruolo</th><th>Fornitore</th><th>Creato</th><th>Azioni</th></tr></thead>
        <tbody id="tb-users"><tr class="empty-row"><td colspan="6">Caricamento...</td></tr></tbody></table>
        <div class="pagination" id="pg-users"></div>
      </div>
    </div>

  </div>
</div>

<div class="overlay" id="modal-overlay" onclick="if(event.target===this)closeModal()">
  <div class="modal-box">
    <div class="modal-head"><h4 id="modal-title">—</h4><button class="modal-close" onclick="closeModal()">✕</button></div>
    <div class="modal-body" id="modal-body"></div>
    <div class="modal-foot" id="modal-foot"></div>
  </div>
</div>

<script>
// ── Base URL ─────────────────────────────────────────────
// All API calls now go through /api/* (routed by .htaccess to api.php via Slim)
const API = '/api';

let TOKEN = localStorage.getItem('admin_token') || null;
let currentUser = null;
let supplierList = [];
let pieceList = [];

// ── Auth ─────────────────────────────────────────────────
async function doLogin() {
  const u = document.getElementById('login-user').value.trim();
  const p = document.getElementById('login-pass').value;
  const errEl = document.getElementById('login-err');
  errEl.style.display = 'none';
  try {
    const r = await post('/login', { username: u, password: p }, true);
    if (!r.ok) throw new Error(r.error);
    if (r.data.user.role !== 'admin') {
      errEl.textContent = 'Accesso consentito solo agli amministratori';
      errEl.style.display = 'block';
      return;
    }
    TOKEN = r.data.token;
    localStorage.setItem('admin_token', TOKEN);
    currentUser = r.data.user;
    showApp();
  } catch (e) { errEl.textContent = e.message; errEl.style.display = 'block'; }
}

async function doLogout() {
  await post('/logout', {});
  TOKEN = null;
  localStorage.removeItem('admin_token');
  location.reload();
}

async function checkSession() {
  if (!TOKEN) return;
  try {
    const r = await get('/me');
    if (r.ok && r.data.role === 'admin') { currentUser = r.data; showApp(); }
    else { TOKEN = null; localStorage.removeItem('admin_token'); }
  } catch (e) { TOKEN = null; localStorage.removeItem('admin_token'); }
}

function showApp() {
  document.getElementById('login-screen').style.display = 'none';
  document.getElementById('sidebar').style.display = 'flex';
  document.getElementById('main').style.display = 'block';
  document.getElementById('sb-username').textContent = currentUser?.username || '—';
  loadStats();
  loadSupplierCache();
  loadPieceCache();
}

// ── HTTP helpers ─────────────────────────────────────────
function authHeaders() {
  const h = { 'Content-Type': 'application/json' };
  if (TOKEN) h['Authorization'] = 'Bearer ' + TOKEN;
  return h;
}
async function get(path, params = {}) {
  const qs = Object.keys(params).length ? '?' + new URLSearchParams(params) : '';
  const r = await fetch(API + path + qs, { headers: authHeaders() });
  return r.json();
}
async function post(path, body, noAuth = false) {
  const headers = { 'Content-Type': 'application/json' };
  if (TOKEN && !noAuth) headers['Authorization'] = 'Bearer ' + TOKEN;
  const r = await fetch(API + path, { method: 'POST', headers, body: JSON.stringify(body) });
  return r.json();
}
async function put(path, body) {
  const r = await fetch(API + path, { method: 'PUT', headers: authHeaders(), body: JSON.stringify(body) });
  return r.json();
}
async function del(path) {
  const r = await fetch(API + path, { method: 'DELETE', headers: authHeaders() });
  return r.json();
}

// ── Navigation ───────────────────────────────────────────
const titles = { overview: 'Panoramica', suppliers: 'Fornitori', pieces: 'Pezzi', catalog: 'Catalogo', users: 'Utenti' };
function showSection(name) {
  document.querySelectorAll('.section-tab').forEach(e => e.classList.remove('active'));
  document.querySelectorAll('.sb-nav a').forEach(a => a.classList.remove('active'));
  document.getElementById('sec-' + name).classList.add('active');
  event.target.closest('a').classList.add('active');
  document.getElementById('top-title').textContent = titles[name] || name;
  if (name === 'suppliers') loadSuppliers(1);
  if (name === 'pieces')    loadPieces(1);
  if (name === 'catalog')   loadCatalog(1);
  if (name === 'users')     loadUsers(1);
}

// ── Stats ─────────────────────────────────────────────────
async function loadStats() {
  const [sf, sp, sc, su] = await Promise.all([
    get('/admin/suppliers', { per_page: 1 }),
    get('/admin/pieces',    { per_page: 1 }),
    get('/admin/catalog',   { per_page: 1 }),
    get('/admin/users',     { per_page: 1 }),
  ]);
  document.getElementById('stat-f').textContent = sf.data?.total ?? '—';
  document.getElementById('stat-p').textContent = sp.data?.total ?? '—';
  document.getElementById('stat-c').textContent = sc.data?.total ?? '—';
  document.getElementById('stat-u').textContent = su.data?.total ?? '—';
}

// ── Cache ─────────────────────────────────────────────────
async function loadSupplierCache() {
  const r = await get('/admin/suppliers', { per_page: 200 });
  supplierList = r.data?.items || [];
  const sel = document.getElementById('filter-cat-fid');
  // clear old options except first
  while (sel.options.length > 1) sel.remove(1);
  supplierList.forEach(f => {
    const o = document.createElement('option');
    o.value = f.fid; o.textContent = f.fnome; sel.appendChild(o);
  });
}
async function loadPieceCache() {
  const r = await get('/admin/pieces', { per_page: 200 });
  pieceList = r.data?.items || [];
}

// ── Color tag ─────────────────────────────────────────────
function colorTag(c) {
  const map = { rosso: 'red', verde: 'green', blu: 'blue', giallo: 'yellow' };
  const cls = map[(c || '').toLowerCase()] || 'other';
  return `<span class="tag tag-${cls}">${c}</span>`;
}

// ── Pagination ────────────────────────────────────────────
function renderPagination(containerId, page, pages, total, loader) {
  const el = document.getElementById(containerId);
  if (!el) return;
  let html = `<div class="info">${total} risultati</div>`;
  if (pages > 1) {
    html += `<button class="page-btn" onclick="${loader}(${page - 1})" ${page <= 1 ? 'disabled' : ''}>‹</button>`;
    for (let i = Math.max(1, page - 2); i <= Math.min(pages, page + 2); i++)
      html += `<button class="page-btn ${i === page ? 'active' : ''}" onclick="${loader}(${i})">${i}</button>`;
    html += `<button class="page-btn" onclick="${loader}(${page + 1})" ${page >= pages ? 'disabled' : ''}>›</button>`;
  }
  el.innerHTML = html;
}

// ── Suppliers ─────────────────────────────────────────────
let supplierPage = 1;
async function loadSuppliers(page = 1) {
  supplierPage = page;
  const search = document.getElementById('search-suppliers')?.value || '';
  const r = await get('/admin/suppliers', { page, per_page: 15, search });
  const tb = document.getElementById('tb-suppliers');
  if (!r.ok) { tb.innerHTML = '<tr class="empty-row"><td colspan="4">Errore</td></tr>'; return; }
  const { items, total, pages } = r.data;
  if (!items.length) { tb.innerHTML = '<tr class="empty-row"><td colspan="4">Nessun risultato</td></tr>'; return; }
  tb.innerHTML = items.map(f => `
    <tr>
      <td class="mono" style="color:var(--muted2)">#${f.fid}</td>
      <td><strong>${esc(f.fnome)}</strong></td>
      <td><span class="tag tag-blue">${f.num_pezzi}</span></td>
      <td style="display:flex;gap:6px;flex-wrap:wrap">
        <button class="btn btn-sm btn-view" onclick="showSupplierDetail(${f.fid})">👁 Dettagli</button>
        <button class="btn btn-sm btn-edit" onclick="openEditSupplier(${f.fid},'${esc(f.fnome)}')">✏️ Modifica</button>
        <button class="btn btn-sm btn-del"  onclick="deleteSupplier(${f.fid})">🗑 Elimina</button>
      </td>
    </tr>`).join('');
  renderPagination('pg-suppliers', page, pages, total, 'loadSuppliers');
}

function openAddSupplier() {
  showFormModal('Aggiungi Fornitore',
    `<div class="form-row"><label>Nome fornitore</label><input id="f-fnome" placeholder="es. Acme"/></div>`,
    async () => {
      const r = await post('/admin/suppliers', { fnome: document.getElementById('f-fnome').value });
      if (!r.ok) throw new Error(r.error);
      loadSuppliers(supplierPage); loadSupplierCache();
    }
  );
}
function openEditSupplier(fid, fnome) {
  showFormModal('Modifica Fornitore',
    `<div class="form-row"><label>Nome fornitore</label><input id="f-fnome" value="${esc(fnome)}"/></div>`,
    async () => {
      const r = await put(`/admin/suppliers/${fid}`, { fnome: document.getElementById('f-fnome').value });
      if (!r.ok) throw new Error(r.error);
      loadSuppliers(supplierPage);
    }
  );
}
async function deleteSupplier(fid) {
  if (!confirm('Eliminare il fornitore? Verranno eliminate anche le voci del suo catalogo.')) return;
  const r = await del(`/admin/suppliers/${fid}`);
  if (!r.ok) alert(r.error); else { loadSuppliers(supplierPage); loadStats(); }
}
async function showSupplierDetail(fid) {
  const r = await get(`/details/supplier/${fid}`);
  if (!r.ok) { showInfoModal('Errore', r.error); return; }
  const { supplier, pieces } = r.data;
  showInfoModal(`Fornitore: ${supplier.fnome}`, `
    <div class="detail-section">
      <h5>Info</h5>
      <div class="detail-grid">
        <div class="detail-item"><div class="dk">ID</div><div class="dv mono">#${supplier.fid}</div></div>
        <div class="detail-item"><div class="dk">Nome</div><div class="dv">${esc(supplier.fnome)}</div></div>
      </div>
    </div>
    <div class="detail-section">
      <h5>Pezzi forniti (${pieces.length})</h5>
      ${pieces.length
        ? `<ul class="detail-list">${pieces.map(p => `<li><span>${colorTag(p.colore)} ${esc(p.pnome)}</span><span class="cost">€${p.costo}</span></li>`).join('')}</ul>`
        : '<p style="color:var(--muted)">Nessun pezzo</p>'}
    </div>`);
}

// ── Pieces ────────────────────────────────────────────────
let piecePage = 1;
async function loadPieces(page = 1) {
  piecePage = page;
  const search = document.getElementById('search-pieces')?.value || '';
  const r = await get('/admin/pieces', { page, per_page: 15, search });
  const tb = document.getElementById('tb-pieces');
  if (!r.ok) { tb.innerHTML = '<tr class="empty-row"><td colspan="5">Errore</td></tr>'; return; }
  const { items, total, pages } = r.data;
  if (!items.length) { tb.innerHTML = '<tr class="empty-row"><td colspan="5">Nessun risultato</td></tr>'; return; }
  tb.innerHTML = items.map(p => `
    <tr>
      <td class="mono" style="color:var(--muted2)">#${p.pid}</td>
      <td><strong>${esc(p.pnome)}</strong></td>
      <td>${colorTag(p.colore)}</td>
      <td><span class="tag tag-blue">${p.num_fornitori}</span></td>
      <td style="display:flex;gap:6px;flex-wrap:wrap">
        <button class="btn btn-sm btn-view" onclick="showPieceDetail(${p.pid})">👁 Dettagli</button>
        <button class="btn btn-sm btn-edit" onclick="openEditPiece(${p.pid},'${esc(p.pnome)}','${esc(p.colore)}')">✏️ Modifica</button>
        <button class="btn btn-sm btn-del"  onclick="deletePiece(${p.pid})">🗑 Elimina</button>
      </td>
    </tr>`).join('');
  renderPagination('pg-pieces', page, pages, total, 'loadPieces');
}

function openAddPiece() {
  showFormModal('Aggiungi Pezzo',
    `<div class="form-row"><label>Nome pezzo</label><input id="f-pnome" placeholder="es. Bullone M8"/></div>
     <div class="form-row"><label>Colore</label><input id="f-colore" placeholder="es. rosso"/></div>`,
    async () => {
      const r = await post('/admin/pieces', { pnome: document.getElementById('f-pnome').value, colore: document.getElementById('f-colore').value });
      if (!r.ok) throw new Error(r.error);
      loadPieces(piecePage); loadPieceCache();
    }
  );
}
function openEditPiece(pid, pnome, colore) {
  showFormModal('Modifica Pezzo',
    `<div class="form-row"><label>Nome pezzo</label><input id="f-pnome" value="${esc(pnome)}"/></div>
     <div class="form-row"><label>Colore</label><input id="f-colore" value="${esc(colore)}"/></div>`,
    async () => {
      const r = await put(`/admin/pieces/${pid}`, { pnome: document.getElementById('f-pnome').value, colore: document.getElementById('f-colore').value });
      if (!r.ok) throw new Error(r.error);
      loadPieces(piecePage);
    }
  );
}
async function deletePiece(pid) {
  if (!confirm('Eliminare il pezzo? Verrà rimosso anche dal catalogo.')) return;
  const r = await del(`/admin/pieces/${pid}`);
  if (!r.ok) alert(r.error); else { loadPieces(piecePage); loadStats(); }
}
async function showPieceDetail(pid) {
  const r = await get(`/details/piece/${pid}`);
  if (!r.ok) { showInfoModal('Errore', r.error); return; }
  const { piece, suppliers } = r.data;
  showInfoModal(`Pezzo: ${piece.pnome}`, `
    <div class="detail-section">
      <h5>Info</h5>
      <div class="detail-grid">
        <div class="detail-item"><div class="dk">ID</div><div class="dv mono">#${piece.pid}</div></div>
        <div class="detail-item"><div class="dk">Nome</div><div class="dv">${esc(piece.pnome)}</div></div>
        <div class="detail-item"><div class="dk">Colore</div><div class="dv">${colorTag(piece.colore)}</div></div>
      </div>
    </div>
    <div class="detail-section">
      <h5>Fornitori (${suppliers.length})</h5>
      ${suppliers.length
        ? `<ul class="detail-list">${suppliers.map(s => `<li><span>${esc(s.fnome)}</span><span class="cost">€${s.costo}</span></li>`).join('')}</ul>`
        : '<p style="color:var(--muted)">Nessun fornitore</p>'}
    </div>`);
}

// ── Catalog ───────────────────────────────────────────────
let catalogPage = 1;
async function loadCatalog(page = 1) {
  catalogPage = page;
  const fid = document.getElementById('filter-cat-fid')?.value || '';
  const params = { page, per_page: 15 };
  if (fid) params.fid = fid;
  const r = await get('/admin/catalog', params);
  const tb = document.getElementById('tb-catalog');
  if (!r.ok) { tb.innerHTML = '<tr class="empty-row"><td colspan="5">Errore</td></tr>'; return; }
  const { items, total, pages } = r.data;
  if (!items.length) { tb.innerHTML = '<tr class="empty-row"><td colspan="5">Nessun risultato</td></tr>'; return; }
  tb.innerHTML = items.map(c => `
    <tr>
      <td><strong>${esc(c.fnome)}</strong></td>
      <td>${esc(c.pnome)}</td>
      <td>${colorTag(c.colore)}</td>
      <td class="mono" style="color:var(--accent)">€${c.costo}</td>
      <td style="display:flex;gap:6px;flex-wrap:wrap">
        <button class="btn btn-sm btn-edit" onclick="openEditCatalog(${c.fid},${c.pid},${c.costo},'${esc(c.fnome)}','${esc(c.pnome)}')">✏️ Modifica</button>
        <button class="btn btn-sm btn-del"  onclick="deleteCatalogEntry(${c.fid},${c.pid})">🗑 Elimina</button>
      </td>
    </tr>`).join('');
  renderPagination('pg-catalog', page, pages, total, 'loadCatalog');
}

function openAddCatalog() {
  const fOpts = supplierList.map(f => `<option value="${f.fid}">${esc(f.fnome)}</option>`).join('');
  const pOpts = pieceList.map(p => `<option value="${p.pid}">${esc(p.pnome)}</option>`).join('');
  showFormModal('Aggiungi voce Catalogo',
    `<div class="form-row"><label>Fornitore</label><select id="f-fid">${fOpts}</select></div>
     <div class="form-row"><label>Pezzo</label><select id="f-pid">${pOpts}</select></div>
     <div class="form-row"><label>Costo (€)</label><input id="f-costo" type="number" step="0.01" placeholder="0.00"/></div>`,
    async () => {
      const r = await post('/admin/catalog', {
        fid: +document.getElementById('f-fid').value,
        pid: +document.getElementById('f-pid').value,
        costo: +document.getElementById('f-costo').value,
      });
      if (!r.ok) throw new Error(r.error);
      loadCatalog(catalogPage); loadStats();
    }
  );
}
function openEditCatalog(fid, pid, costo, fnome, pnome) {
  showFormModal('Modifica Costo',
    `<div style="color:var(--muted2);font-size:.85rem;margin-bottom:16px">${esc(fnome)} → ${esc(pnome)}</div>
     <div class="form-row"><label>Costo (€)</label><input id="f-costo" type="number" step="0.01" value="${costo}"/></div>`,
    async () => {
      const r = await put(`/admin/catalog/${fid}/${pid}`, { costo: +document.getElementById('f-costo').value });
      if (!r.ok) throw new Error(r.error);
      loadCatalog(catalogPage);
    }
  );
}
async function deleteCatalogEntry(fid, pid) {
  if (!confirm('Eliminare questa voce dal catalogo?')) return;
  const r = await del(`/admin/catalog/${fid}/${pid}`);
  if (!r.ok) alert(r.error); else { loadCatalog(catalogPage); loadStats(); }
}

// ── Users ─────────────────────────────────────────────────
let userPage = 1;
async function loadUsers(page = 1) {
  userPage = page;
  const r = await get('/admin/users', { page, per_page: 15 });
  const tb = document.getElementById('tb-users');
  if (!r.ok) { tb.innerHTML = '<tr class="empty-row"><td colspan="6">Errore</td></tr>'; return; }
  const { items, total, pages } = r.data;
  if (!items.length) { tb.innerHTML = '<tr class="empty-row"><td colspan="6">Nessun risultato</td></tr>'; return; }
  tb.innerHTML = items.map(u => `
    <tr>
      <td class="mono" style="color:var(--muted2)">#${u.uid}</td>
      <td><strong>${esc(u.username)}</strong></td>
      <td><span class="tag tag-${u.role === 'admin' ? 'admin' : 'supplier'}">${u.role}</span></td>
      <td>${u.fnome ? esc(u.fnome) : '<span style="color:var(--muted)">—</span>'}</td>
      <td style="color:var(--muted2);font-size:.78rem">${u.created_at?.slice(0, 10) || '—'}</td>
      <td style="display:flex;gap:6px;flex-wrap:wrap">
        <button class="btn btn-sm btn-edit" onclick="openEditUser(${u.uid},'${esc(u.username)}','${u.role}',${u.fid || 'null'})">✏️ Modifica</button>
        <button class="btn btn-sm btn-del"  onclick="deleteUser(${u.uid})">🗑 Elimina</button>
      </td>
    </tr>`).join('');
  renderPagination('pg-users', page, pages, total, 'loadUsers');
}

function openAddUser() {
  const fOpts = '<option value="">Nessuno</option>' + supplierList.map(f => `<option value="${f.fid}">${esc(f.fnome)}</option>`).join('');
  showFormModal('Aggiungi Utente',
    `<div class="form-row"><label>Username</label><input id="f-uname"/></div>
     <div class="form-row"><label>Password</label><input id="f-pw" type="password"/></div>
     <div class="form-row"><label>Ruolo</label><select id="f-role"><option value="supplier">supplier</option><option value="admin">admin</option></select></div>
     <div class="form-row"><label>Fornitore (solo supplier)</label><select id="f-fid">${fOpts}</select></div>`,
    async () => {
      const r = await post('/admin/users', {
        username: document.getElementById('f-uname').value,
        password: document.getElementById('f-pw').value,
        role: document.getElementById('f-role').value,
        fid: document.getElementById('f-fid').value || null,
      });
      if (!r.ok) throw new Error(r.error);
      loadUsers(userPage); loadStats();
    }
  );
}
function openEditUser(uid, username, role, fid) {
  const fOpts = '<option value="">Nessuno</option>' + supplierList.map(f => `<option value="${f.fid}" ${f.fid == fid ? 'selected' : ''}>${esc(f.fnome)}</option>`).join('');
  showFormModal('Modifica Utente',
    `<div class="form-row"><label>Username</label><input id="f-uname" value="${esc(username)}"/></div>
     <div class="form-row"><label>Nuova password (vuoto = invariata)</label><input id="f-pw" type="password"/></div>
     <div class="form-row"><label>Ruolo</label><select id="f-role"><option value="supplier" ${role === 'supplier' ? 'selected' : ''}>supplier</option><option value="admin" ${role === 'admin' ? 'selected' : ''}>admin</option></select></div>
     <div class="form-row"><label>Fornitore</label><select id="f-fid">${fOpts}</select></div>`,
    async () => {
      const body = {
        username: document.getElementById('f-uname').value,
        role: document.getElementById('f-role').value,
        fid: document.getElementById('f-fid').value || null,
      };
      const pw = document.getElementById('f-pw').value;
      if (pw) body.password = pw;
      const r = await put(`/admin/users/${uid}`, body);
      if (!r.ok) throw new Error(r.error);
      loadUsers(userPage);
    }
  );
}
async function deleteUser(uid) {
  if (!confirm('Eliminare questo utente?')) return;
  const r = await del(`/admin/users/${uid}`);
  if (!r.ok) alert(r.error); else { loadUsers(userPage); loadStats(); }
}

// ── Modal helpers ─────────────────────────────────────────
function showFormModal(title, bodyHtml, onSave) {
  document.getElementById('modal-title').textContent = title;
  document.getElementById('modal-body').innerHTML = bodyHtml;
  document.getElementById('modal-foot').innerHTML =
    `<button class="btn btn-secondary" onclick="closeModal()">Annulla</button>
     <button class="btn btn-primary" id="btn-modal-save">Salva</button>`;
  document.getElementById('btn-modal-save').onclick = async () => {
    const btn = document.getElementById('btn-modal-save');
    btn.disabled = true; btn.textContent = 'Salvataggio...';
    try { await onSave(); closeModal(); }
    catch (e) { alert('Errore: ' + e.message); btn.disabled = false; btn.textContent = 'Salva'; }
  };
  document.getElementById('modal-overlay').classList.add('open');
}
function showInfoModal(title, bodyHtml) {
  document.getElementById('modal-title').textContent = title;
  document.getElementById('modal-body').innerHTML = bodyHtml;
  document.getElementById('modal-foot').innerHTML =
    `<button class="btn btn-secondary" onclick="closeModal()">Chiudi</button>`;
  document.getElementById('modal-overlay').classList.add('open');
}
function closeModal() { document.getElementById('modal-overlay').classList.remove('open'); }

// ── Utils ─────────────────────────────────────────────────
function esc(s) { return String(s || '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

// ── Boot ──────────────────────────────────────────────────
document.getElementById('login-pass').addEventListener('keydown', e => { if (e.key === 'Enter') doLogin(); });
checkSession();
</script>
</body>
</html>
