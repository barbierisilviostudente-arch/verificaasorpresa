<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>Portale Fornitori — Catalogo</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet"/>
<style>
:root{
  --bg:#f4f6fa;--surface:#fff;--border:#e2e6ed;
  --accent:#2563eb;--accent-light:#eff3ff;--accent-dark:#1d4ed8;
  --success:#059669;--success-light:#ecfdf5;
  --danger:#dc2626;--danger-light:#fef2f2;
  --text:#0f172a;--muted:#64748b;--muted2:#94a3b8;
  --font:"DM Sans",sans-serif;--mono:"DM Mono",monospace;
}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:var(--font);background:var(--bg);color:var(--text);min-height:100vh}
#login-screen{min-height:100vh;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#1e3a8a 0%,#2563eb 50%,#0ea5e9 100%)}
.login-box{background:#fff;border-radius:20px;padding:48px 40px;width:400px;box-shadow:0 20px 60px rgba(0,0,0,.2)}
.login-logo{width:52px;height:52px;background:var(--accent-light);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.5rem;margin:0 auto 20px}
.login-box h1{font-size:1.5rem;font-weight:700;text-align:center;margin-bottom:4px}
.login-box .sub{color:var(--muted);font-size:.88rem;text-align:center;margin-bottom:32px}
.field{margin-bottom:16px}
.field label{display:block;font-size:.78rem;font-weight:600;color:var(--muted);text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px}
.field input{width:100%;border:1.5px solid var(--border);border-radius:9px;padding:11px 14px;color:var(--text);font-family:var(--font);font-size:.9rem;outline:none;transition:border-color .2s}
.field input:focus{border-color:var(--accent)}
.btn-login{width:100%;background:var(--accent);color:#fff;font-family:var(--font);font-weight:700;font-size:.95rem;border:none;border-radius:9px;padding:13px;cursor:pointer;margin-top:8px;transition:background .2s}
.btn-login:hover{background:var(--accent-dark)}
.login-err{color:var(--danger);font-size:.82rem;margin-top:10px;text-align:center;display:none;background:var(--danger-light);border-radius:7px;padding:8px 12px}
#app{display:none;min-height:100vh}
header{background:#fff;border-bottom:1px solid var(--border);padding:0 32px;height:64px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:100;box-shadow:0 1px 3px rgba(0,0,0,.06)}
.header-left{display:flex;align-items:center;gap:14px}
.header-logo{width:36px;height:36px;background:var(--accent);border-radius:9px;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:.9rem}
.header-title{font-size:1rem;font-weight:700}
.header-title span{color:var(--accent);font-size:.78rem;display:block;font-weight:500}
.header-right{display:flex;align-items:center;gap:14px}
.user-chip{display:flex;align-items:center;gap:8px;background:var(--bg);border:1px solid var(--border);border-radius:20px;padding:5px 14px 5px 8px;font-size:.82rem}
.user-avatar{width:24px;height:24px;background:var(--accent);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-size:.7rem;font-weight:700}
.btn-logout-sm{background:none;border:none;color:var(--muted);font-size:.8rem;cursor:pointer;font-family:var(--font);padding:4px 10px;border-radius:6px}
.btn-logout-sm:hover{color:var(--danger);background:var(--danger-light)}
.page-wrap{max-width:960px;margin:0 auto;padding:32px 24px}
.page-header{margin-bottom:24px}
.page-header h2{font-size:1.4rem;font-weight:700;margin-bottom:4px}
.page-header p{color:var(--muted);font-size:.88rem}
.supplier-info{background:var(--accent-light);border:1px solid #bfdbfe;border-radius:10px;padding:14px 20px;margin-bottom:24px;display:flex;align-items:center;gap:12px}
.supplier-info .ico{font-size:1.3rem}
.supplier-info .txt strong{font-size:.9rem}
.supplier-info .txt small{color:var(--muted);font-size:.78rem;display:block}
.tcard{background:#fff;border:1px solid var(--border);border-radius:12px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.06)}
.tc-header{padding:16px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px}
.tc-header h3{font-size:.95rem;font-weight:700;flex:1}
.btn{display:inline-flex;align-items:center;gap:5px;padding:8px 16px;border-radius:8px;font-family:var(--font);font-size:.82rem;font-weight:600;border:none;cursor:pointer;transition:all .15s}
.btn-primary{background:var(--accent);color:#fff}
.btn-primary:hover{background:var(--accent-dark)}
.btn-sm{padding:5px 11px;font-size:.75rem}
.btn-edit{background:#f0f9ff;color:#0369a1;border:1px solid #bae6fd}
.btn-edit:hover{background:#e0f2fe}
.btn-del{background:var(--danger-light);color:var(--danger);border:1px solid #fecaca}
.btn-del:hover{background:#fee2e2}
.btn-view{background:var(--success-light);color:var(--success);border:1px solid #a7f3d0}
.btn-view:hover{background:#d1fae5}
.btn-secondary{background:var(--bg);color:var(--muted);border:1px solid var(--border)}
.btn-secondary:hover{color:var(--text)}
table{width:100%;border-collapse:collapse}
thead th{padding:10px 16px;font-size:.7rem;text-transform:uppercase;letter-spacing:.07em;color:var(--muted);font-weight:700;text-align:left;background:#f8fafc;border-bottom:1px solid var(--border)}
tbody tr{border-bottom:1px solid var(--border);transition:background .1s}
tbody tr:last-child{border:none}
tbody tr:hover{background:#fafbfc}
tbody td{padding:11px 16px;font-size:.87rem}
.tag{display:inline-block;padding:2px 9px;border-radius:20px;font-size:.7rem;font-weight:700}
.tag-red{background:#fff1f2;color:#e11d48}
.tag-green{background:#f0fdf4;color:#16a34a}
.tag-blue{background:#eff6ff;color:#2563eb}
.tag-yellow{background:#fefce8;color:#ca8a04}
.tag-other{background:#f1f5f9;color:#64748b}
.pagination{display:flex;align-items:center;gap:6px;padding:14px 20px;border-top:1px solid var(--border);background:#fafbfc}
.pagination .info{font-size:.78rem;color:var(--muted);flex:1}
.page-btn{background:#fff;border:1px solid var(--border);color:var(--muted);padding:5px 10px;border-radius:6px;cursor:pointer;font-size:.75rem;font-family:var(--mono);transition:all .15s}
.page-btn:hover{border-color:var(--accent);color:var(--accent)}
.page-btn.active{background:var(--accent);border-color:var(--accent);color:#fff}
.page-btn:disabled{opacity:.4;cursor:not-allowed}
.overlay{position:fixed;inset:0;background:rgba(15,23,42,.5);backdrop-filter:blur(3px);z-index:1000;display:none;align-items:center;justify-content:center}
.overlay.open{display:flex}
.modal-box{background:#fff;border-radius:16px;width:480px;max-width:95vw;max-height:88vh;overflow:hidden;display:flex;flex-direction:column;box-shadow:0 24px 60px rgba(0,0,0,.2);animation:slideUp .2s ease}
@keyframes slideUp{from{transform:translateY(16px);opacity:0}to{transform:translateY(0);opacity:1}}
.modal-head{padding:20px 24px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between}
.modal-head h4{font-size:1rem;font-weight:700}
.modal-close{background:none;border:none;color:var(--muted2);font-size:1.2rem;cursor:pointer;border-radius:6px;padding:2px 6px}
.modal-close:hover{background:var(--bg);color:var(--danger)}
.modal-body{padding:24px;overflow-y:auto;flex:1}
.modal-foot{padding:16px 24px;border-top:1px solid var(--border);display:flex;gap:10px;justify-content:flex-end;background:#fafbfc}
.form-row{margin-bottom:16px}
.form-row label{display:block;font-size:.75rem;font-weight:600;color:var(--muted);text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px}
.form-row input,.form-row select{width:100%;border:1.5px solid var(--border);border-radius:8px;padding:10px 13px;color:var(--text);font-family:var(--font);font-size:.88rem;outline:none;transition:border-color .2s}
.form-row input:focus,.form-row select:focus{border-color:var(--accent)}
.detail-section{margin-bottom:20px}
.detail-section h5{font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:var(--accent);margin-bottom:10px;padding-bottom:8px;border-bottom:1px solid var(--border)}
.detail-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:4px}
.di{background:var(--bg);border:1px solid var(--border);border-radius:7px;padding:10px 12px}
.di .dk{font-size:.68rem;text-transform:uppercase;letter-spacing:.08em;color:var(--muted2);margin-bottom:3px}
.di .dv{font-size:.9rem;font-weight:600}
.detail-list{list-style:none}
.detail-list li{display:flex;align-items:center;justify-content:space-between;padding:9px 0;border-bottom:1px solid var(--border)}
.detail-list li:last-child{border:none}
.cost{font-family:var(--mono);font-size:.82rem;color:var(--success);font-weight:600}
.empty-row td{text-align:center;padding:48px;color:var(--muted);font-size:.88rem}
.mono{font-family:var(--mono)}
.alert-box{border-radius:9px;padding:12px 16px;font-size:.85rem;margin-bottom:16px;display:none}
.alert-err{background:var(--danger-light);color:var(--danger);border:1px solid #fecaca}
.alert-ok{background:var(--success-light);color:var(--success);border:1px solid #a7f3d0}
</style>
</head>
<body>

<div id="login-screen">
  <div class="login-box">
    <div class="login-logo">🏭</div>
    <h1>Portale Fornitori</h1>
    <div class="sub">Gestisci il tuo catalogo prodotti</div>
    <div class="field"><label>Username</label><input type="text" id="login-user" placeholder="es. acme" autocomplete="username"/></div>
    <div class="field"><label>Password</label><input type="password" id="login-pass" placeholder="••••••••" autocomplete="current-password"/></div>
    <button class="btn-login" onclick="doLogin()">Accedi</button>
    <div class="login-err" id="login-err"></div>
  </div>
</div>

<div id="app">
  <header>
    <div class="header-left">
      <div class="header-logo">CB</div>
      <div class="header-title">Portale Fornitori<span>Gestione Catalogo</span></div>
    </div>
    <div class="header-right">
      <div class="user-chip">
        <div class="user-avatar" id="user-avatar">?</div>
        <span id="user-name">—</span>
      </div>
      <button class="btn-logout-sm" onclick="doLogout()">Esci →</button>
    </div>
  </header>

  <div class="page-wrap">
    <div class="page-header">
      <h2>Il tuo catalogo</h2>
      <p>Aggiungi, modifica o rimuovi i pezzi che fornisci. Fai click su una riga per vedere i dettagli.</p>
    </div>
    <div class="supplier-info">
      <span class="ico">🏭</span>
      <div class="txt"><strong id="info-supplier">—</strong><small id="info-role">—</small></div>
    </div>
    <div class="alert-box alert-err" id="alert-err"></div>
    <div class="alert-box alert-ok"  id="alert-ok"></div>
    <div class="tcard">
      <div class="tc-header">
        <h3>Pezzi nel catalogo</h3>
        <span id="catalog-count" style="color:var(--muted);font-size:.8rem"></span>
        <button class="btn btn-primary btn-sm" onclick="openAddEntry()">+ Aggiungi pezzo</button>
      </div>
      <table>
        <thead><tr><th>Pezzo</th><th>Colore</th><th>Costo (€)</th><th>Azioni</th></tr></thead>
        <tbody id="tb-catalog"><tr class="empty-row"><td colspan="4">Caricamento...</td></tr></tbody>
      </table>
      <div class="pagination" id="pg-catalog"></div>
    </div>
  </div>
</div>

<div class="overlay" id="overlay" onclick="if(event.target===this)closeModal()">
  <div class="modal-box">
    <div class="modal-head"><h4 id="modal-title">—</h4><button class="modal-close" onclick="closeModal()">✕</button></div>
    <div class="modal-body" id="modal-body"></div>
    <div class="modal-foot" id="modal-foot"></div>
  </div>
</div>

<script>
// ── Base URL ─────────────────────────────────────────────
const API = '/api';

let TOKEN     = localStorage.getItem('supplier_token') || null;
let ME        = null;
let pieceList = [];
let catalogPage = 1;

// ── Auth ──────────────────────────────────────────────────
async function doLogin() {
  const u   = document.getElementById('login-user').value.trim();
  const p   = document.getElementById('login-pass').value;
  const err = document.getElementById('login-err');
  err.style.display = 'none';
  try {
    const r = await fetch(`${API}/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: u, password: p }),
    });
    const d = await r.json();
    if (!d.ok) throw new Error(d.error);
    TOKEN = d.data.token;
    ME    = d.data.user;
    localStorage.setItem('supplier_token', TOKEN);
    showApp();
  } catch (e) { err.textContent = e.message; err.style.display = 'block'; }
}

async function doLogout() {
  await fetch(`${API}/logout`, { method: 'POST', headers: authHeaders() });
  TOKEN = null; ME = null;
  localStorage.removeItem('supplier_token');
  location.reload();
}

async function checkSession() {
  if (!TOKEN) return;
  try {
    const r = await fetch(`${API}/me`, { headers: authHeaders() });
    const d = await r.json();
    if (d.ok) { ME = d.data; showApp(); }
    else { TOKEN = null; localStorage.removeItem('supplier_token'); }
  } catch (e) { TOKEN = null; localStorage.removeItem('supplier_token'); }
}

function showApp() {
  document.getElementById('login-screen').style.display = 'none';
  document.getElementById('app').style.display = 'block';
  const initials = (ME.username || '?').slice(0, 2).toUpperCase();
  document.getElementById('user-avatar').textContent = initials;
  document.getElementById('user-name').textContent   = ME.username;
  document.getElementById('info-supplier').textContent = ME.role === 'admin' ? 'Amministratore' : `Fornitore (ID: ${ME.fid})`;
  document.getElementById('info-role').textContent     = ME.role === 'admin' ? 'Accesso admin' : `Ruolo: ${ME.role}`;
  loadPieceCache().then(() => loadCatalog(1));
}

// ── HTTP helpers ──────────────────────────────────────────
function authHeaders() {
  const h = { 'Content-Type': 'application/json' };
  if (TOKEN) h['Authorization'] = 'Bearer ' + TOKEN;
  return h;
}
async function get(path, params = {}) {
  const qs = Object.keys(params).length ? '?' + new URLSearchParams(params) : '';
  const r = await fetch(API + path + qs, { headers: authHeaders() });
  return r.json();
}
async function post(path, body) {
  const r = await fetch(API + path, { method: 'POST', headers: authHeaders(), body: JSON.stringify(body) });
  return r.json();
}
async function put(path, body) {
  const r = await fetch(API + path, { method: 'PUT', headers: authHeaders(), body: JSON.stringify(body) });
  return r.json();
}
async function del(path) {
  const r = await fetch(API + path, { method: 'DELETE', headers: authHeaders() });
  return r.json();
}

// ── Piece cache (for add-entry dropdown) ──────────────────
async function loadPieceCache() {
  // /admin/pieces requires admin role; for suppliers we get available pieces
  // from a broad my-catalog call or fall back to empty list gracefully
  const r = await get('/admin/pieces', { per_page: 200 });
  if (r.ok) pieceList = r.data.items;
}

// ── Catalog ───────────────────────────────────────────────
async function loadCatalog(page = 1) {
  catalogPage = page;
  const r = await get('/my-catalog', { page, per_page: 10 });
  const tb = document.getElementById('tb-catalog');
  if (!r.ok) { tb.innerHTML = `<tr class="empty-row"><td colspan="4">${esc(r.error)}</td></tr>`; return; }
  const { items, total, pages } = r.data;
  document.getElementById('catalog-count').textContent = `${total} pezzi`;
  if (!items.length) {
    tb.innerHTML = '<tr class="empty-row"><td colspan="4">Nessun pezzo nel catalogo. Aggiungine uno!</td></tr>';
    document.getElementById('pg-catalog').innerHTML = '';
    return;
  }
  tb.innerHTML = items.map(i => `
    <tr style="cursor:pointer" onclick="showPieceDetail(${i.pid})">
      <td><strong>${esc(i.pnome)}</strong></td>
      <td>${colorTag(i.colore)}</td>
      <td class="mono" style="color:var(--success)">€${i.costo}</td>
      <td onclick="event.stopPropagation()" style="display:flex;gap:6px;flex-wrap:wrap">
        <button class="btn btn-sm btn-view" onclick="showPieceDetail(${i.pid})">👁</button>
        <button class="btn btn-sm btn-edit" onclick="openEditEntry(${i.pid},'${esc(i.pnome)}',${i.costo})">✏️ Prezzo</button>
        <button class="btn btn-sm btn-del"  onclick="deleteEntry(${i.pid})">🗑</button>
      </td>
    </tr>`).join('');
  renderPagination('pg-catalog', page, pages, total, 'loadCatalog');
}

// ── CRUD ──────────────────────────────────────────────────
function openAddEntry() {
  const pOpts = pieceList.map(p => `<option value="${p.pid}">${esc(p.pnome)} (${esc(p.colore)})</option>`).join('');
  if (!pOpts) { showAlert('err', 'Nessun pezzo disponibile.'); return; }
  showFormModal('Aggiungi pezzo al catalogo',
    `<div class="form-row"><label>Pezzo</label><select id="f-pid">${pOpts}</select></div>
     <div class="form-row"><label>Costo (€)</label><input id="f-costo" type="number" step="0.01" min="0" placeholder="0.00"/></div>`,
    async () => {
      const r = await post('/my-catalog', {
        pid: +document.getElementById('f-pid').value,
        costo: +document.getElementById('f-costo').value,
      });
      if (!r.ok) throw new Error(r.error);
      showAlert('ok', 'Pezzo aggiunto al catalogo.');
      loadCatalog(catalogPage);
    }
  );
}

function openEditEntry(pid, pnome, costo) {
  showFormModal(`Modifica prezzo: ${pnome}`,
    `<div class="form-row"><label>Costo (€)</label><input id="f-costo" type="number" step="0.01" min="0" value="${costo}"/></div>`,
    async () => {
      const r = await put(`/my-catalog/${pid}`, { costo: +document.getElementById('f-costo').value });
      if (!r.ok) throw new Error(r.error);
      showAlert('ok', 'Prezzo aggiornato.');
      loadCatalog(catalogPage);
    }
  );
}

async function deleteEntry(pid) {
  if (!confirm('Rimuovere questo pezzo dal tuo catalogo?')) return;
  const r = await del(`/my-catalog/${pid}`);
  if (!r.ok) { showAlert('err', r.error); return; }
  showAlert('ok', 'Pezzo rimosso dal catalogo.');
  loadCatalog(catalogPage);
}

// ── Detail modal ──────────────────────────────────────────
async function showPieceDetail(pid) {
  const r = await get(`/details/piece/${pid}`);
  if (!r.ok) { showInfoModal('Errore', r.error); return; }
  const { piece, suppliers } = r.data;
  showInfoModal(`Dettagli: ${piece.pnome}`, `
    <div class="detail-section">
      <h5>Informazioni pezzo</h5>
      <div class="detail-grid">
        <div class="di"><div class="dk">ID</div><div class="dv mono">#${piece.pid}</div></div>
        <div class="di"><div class="dk">Nome</div><div class="dv">${esc(piece.pnome)}</div></div>
        <div class="di"><div class="dk">Colore</div><div class="dv">${colorTag(piece.colore)}</div></div>
        <div class="di"><div class="dk">Fornitori</div><div class="dv">${suppliers.length}</div></div>
      </div>
    </div>
    <div class="detail-section">
      <h5>Fornitori che lo vendono</h5>
      ${suppliers.length
        ? `<ul class="detail-list">${suppliers.map(s => `<li><span>${esc(s.fnome)}</span><span class="cost">€${s.costo}</span></li>`).join('')}</ul>`
        : '<p style="color:var(--muted)">Nessun fornitore</p>'}
    </div>`);
}

// ── Pagination ────────────────────────────────────────────
function renderPagination(containerId, page, pages, total, loader) {
  const el = document.getElementById(containerId);
  if (!el) return;
  let html = `<div class="info">${total} risultati</div>`;
  if (pages > 1) {
    html += `<button class="page-btn" onclick="${loader}(${page - 1})" ${page <= 1 ? 'disabled' : ''}>‹</button>`;
    for (let i = Math.max(1, page - 2); i <= Math.min(pages, page + 2); i++)
      html += `<button class="page-btn ${i === page ? 'active' : ''}" onclick="${loader}(${i})">${i}</button>`;
    html += `<button class="page-btn" onclick="${loader}(${page + 1})" ${page >= pages ? 'disabled' : ''}>›</button>`;
  }
  el.innerHTML = html;
}

// ── Modals ────────────────────────────────────────────────
function showFormModal(title, bodyHtml, onSave) {
  document.getElementById('modal-title').textContent = title;
  document.getElementById('modal-body').innerHTML = bodyHtml;
  document.getElementById('modal-foot').innerHTML =
    `<button class="btn btn-secondary" onclick="closeModal()">Annulla</button>
     <button class="btn btn-primary" id="btn-save">Salva</button>`;
  document.getElementById('btn-save').onclick = async () => {
    const btn = document.getElementById('btn-save');
    btn.disabled = true; btn.textContent = 'Salvataggio...';
    try { await onSave(); closeModal(); }
    catch (e) { alert('Errore: ' + e.message); btn.disabled = false; btn.textContent = 'Salva'; }
  };
  document.getElementById('overlay').classList.add('open');
}
function showInfoModal(title, bodyHtml) {
  document.getElementById('modal-title').textContent = title;
  document.getElementById('modal-body').innerHTML = bodyHtml;
  document.getElementById('modal-foot').innerHTML =
    `<button class="btn btn-secondary" onclick="closeModal()">Chiudi</button>`;
  document.getElementById('overlay').classList.add('open');
}
function closeModal() { document.getElementById('overlay').classList.remove('open'); }

// ── Alert ─────────────────────────────────────────────────
function showAlert(type, msg) {
  const id = 'alert-' + (type === 'ok' ? 'ok' : 'err');
  const el = document.getElementById(id);
  el.textContent = msg; el.style.display = 'block';
  setTimeout(() => { el.style.display = 'none'; }, 4000);
}

// ── Utils ─────────────────────────────────────────────────
function colorTag(c) {
  const map = { rosso: 'red', verde: 'green', blu: 'blue', giallo: 'yellow' };
  const cls = map[(c || '').toLowerCase()] || 'other';
  return `<span class="tag tag-${cls}">${c || '—'}</span>`;
}
function esc(s) { return String(s || '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

// ── Boot ──────────────────────────────────────────────────
document.getElementById('login-pass').addEventListener('keydown', e => { if (e.key === 'Enter') doLogin(); });
checkSession();
</script>
</body>
</html>
