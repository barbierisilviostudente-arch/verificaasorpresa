<?php
// ============================================================
// api.php  –  REST API built on Slim Framework 4
// ============================================================
// Requires (via composer):
//   slim/slim   ^4.0
//   slim/psr7   ^1.8
//
// Routes:
//   POST   /login
//   POST   /logout
//   GET    /me
//
//   GET    /queries/{n}              ?page &per_page
//   GET    /details/{type}/{id}      type = piece | supplier
//
//   GET    /my-catalog               ?page &per_page   (supplier | admin)
//   POST   /my-catalog               { pid, costo }
//   PUT    /my-catalog/{pid}         { costo }
//   DELETE /my-catalog/{pid}
//
//   GET    /admin/suppliers          ?page &search     (admin only)
//   POST   /admin/suppliers          { fnome }
//   PUT    /admin/suppliers/{id}     { fnome }
//   DELETE /admin/suppliers/{id}
//
//   GET    /admin/pieces             ?page &search
//   POST   /admin/pieces             { pnome, colore }
//   PUT    /admin/pieces/{id}        { pnome, colore }
//   DELETE /admin/pieces/{id}
//
//   GET    /admin/catalog            ?page &fid &pid
//   POST   /admin/catalog            { fid, pid, costo }
//   PUT    /admin/catalog/{fid}/{pid} { costo }
//   DELETE /admin/catalog/{fid}/{pid}
//
//   GET    /admin/users              ?page
//   POST   /admin/users              { username, password, role, fid? }
//   PUT    /admin/users/{id}         { username?, password?, role?, fid? }
//   DELETE /admin/users/{id}
// ============================================================

declare(strict_types=1);

require __DIR__ . '/vendor/autoload.php';

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Server\RequestHandlerInterface as Handler;
use Slim\Factory\AppFactory;
use Slim\Exception\HttpNotFoundException;

// ── App factory ───────────────────────────────────────────
$app = AppFactory::create();

// ── JSON Error Handler ────────────────────────────────────
// Replaces Slim's default HTML error pages with clean JSON responses.
$errorMiddleware = $app->addErrorMiddleware(
    displayErrorDetails: false,  // set to true locally for debugging
    logErrors: true,
    logErrorDetails: false
);

$errorMiddleware->setDefaultErrorHandler(
    function (Request $request, Throwable $exception, bool $displayErrorDetails) use ($app): Response {
        $code = 500;
        $msg  = 'Errore interno del server';

        if ($exception instanceof HttpNotFoundException) {
            $code = 404; $msg = 'Endpoint non trovato';
        } elseif ($exception instanceof \Slim\Exception\HttpMethodNotAllowedException) {
            $code = 405; $msg = 'Metodo HTTP non consentito';
        } elseif ($exception instanceof \RuntimeException) {
            // Domain exceptions carry the HTTP status code as the exception code.
            $code = (int) $exception->getCode() ?: 500;
            $msg  = $exception->getMessage();
        }

        $response = $app->getResponseFactory()->createResponse($code);
        $response->getBody()->write(json_encode(
            ['ok' => false, 'error' => $msg],
            JSON_UNESCAPED_UNICODE
        ));
        return $response->withHeader('Content-Type', 'application/json; charset=utf-8');
    }
);

// ── CORS middleware ───────────────────────────────────────
$app->add(function (Request $request, Handler $handler): Response {
    $response = $handler->handle($request);
    return $response
        ->withHeader('Access-Control-Allow-Origin',  '*')
        ->withHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        ->withHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
});

$app->options('/{routes:.+}', function (Request $request, Response $response): Response {
    return $response->withStatus(204);
});

// ── DB (singleton) ────────────────────────────────────────
function makeDB(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO(
            'mysql:host=127.0.0.1;dbname=verificaasorpresa;charset=utf8mb4',
            'a', 'a',
            [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]
        );
    }
    return $pdo;
}

// ── Helpers ───────────────────────────────────────────────

function jsonOk(Response $response, mixed $data, int $status = 200): Response
{
    $response->getBody()->write(json_encode(
        ['ok' => true, 'data' => $data],
        JSON_UNESCAPED_UNICODE
    ));
    return $response
        ->withHeader('Content-Type', 'application/json; charset=utf-8')
        ->withStatus($status);
}

/** Throw a RuntimeException caught by the JSON error handler. */
function abort(int $code, string $message): never
{
    throw new \RuntimeException($message, $code);
}

function bodyParams(Request $request): array
{
    $parsed = $request->getParsedBody() ?? [];
    return is_array($parsed) ? $parsed : [];
}

function qdb(PDO $pdo, string $sql, array $params = []): array
{
    $st = $pdo->prepare($sql);
    $st->execute($params);
    return $st->fetchAll();
}

function paginate(PDO $pdo, string $countSql, string $dataSql, array $params, int $page, int $perPage): array
{
    $stC = $pdo->prepare($countSql);
    $stC->execute($params);
    $total  = (int) $stC->fetchColumn();
    $offset = ($page - 1) * $perPage;

    $stD = $pdo->prepare("$dataSql LIMIT $perPage OFFSET $offset");
    $stD->execute($params);

    return [
        'items'    => $stD->fetchAll(),
        'total'    => $total,
        'page'     => $page,
        'per_page' => $perPage,
        'pages'    => max(1, (int) ceil($total / $perPage)),
    ];
}

function pageParams(Request $request, int $defaultPP = 20): array
{
    $q = $request->getQueryParams();
    return [
        max(1, (int) ($q['page']     ?? 1)),
        max(1, min(100, (int) ($q['per_page'] ?? $defaultPP))),
    ];
}

// ── Auth helpers ──────────────────────────────────────────

function tokenFromRequest(Request $request): ?string
{
    $header = $request->getHeaderLine('Authorization');
    if (preg_match('/Bearer\s+(.+)/i', $header, $m)) return $m[1];
    return $request->getQueryParams()['token'] ?? null;
}

function currentUser(Request $request, PDO $pdo): ?array
{
    $token = tokenFromRequest($request);
    if (!$token) return null;
    $rows = qdb($pdo,
        "SELECT u.* FROM Sessions s JOIN Users u ON u.uid = s.uid
         WHERE s.token = ? AND s.expires_at > NOW()",
        [$token]
    );
    return $rows[0] ?? null;
}

function requireAuth(Request $request, PDO $pdo): array
{
    $user = currentUser($request, $pdo);
    if (!$user) abort(401, 'Non autenticato');
    return $user;
}

function requireAdmin(Request $request, PDO $pdo): array
{
    $user = requireAuth($request, $pdo);
    if ($user['role'] !== 'admin') abort(403, 'Solo gli amministratori possono eseguire questa operazione');
    return $user;
}

// ============================================================
// ROUTES
// ============================================================

// ── Auth ──────────────────────────────────────────────────

$app->post('/login', function (Request $request, Response $response): Response {
    $pdo      = makeDB();
    $body     = bodyParams($request);
    $username = trim($body['username'] ?? '');
    $password = $body['password'] ?? '';
    if (!$username || !$password) abort(400, 'Username e password obbligatori');

    $rows = qdb($pdo, "SELECT * FROM Users WHERE username = ?", [$username]);
    $user = $rows[0] ?? null;
    if (!$user || !password_verify($password, $user['password'])) abort(401, 'Credenziali non valide');

    $token   = bin2hex(random_bytes(32));
    $expires = date('Y-m-d H:i:s', strtotime('+8 hours'));
    $pdo->prepare("INSERT INTO Sessions (token, uid, expires_at) VALUES (?, ?, ?)")
        ->execute([$token, $user['uid'], $expires]);

    unset($user['password']);
    return jsonOk($response, ['token' => $token, 'expires_at' => $expires, 'user' => $user]);
});

$app->post('/logout', function (Request $request, Response $response): Response {
    $token = tokenFromRequest($request);
    if ($token) makeDB()->prepare("DELETE FROM Sessions WHERE token = ?")->execute([$token]);
    return jsonOk($response, ['message' => 'Disconnesso']);
});

$app->get('/me', function (Request $request, Response $response): Response {
    $user = requireAuth($request, makeDB());
    unset($user['password']);
    return jsonOk($response, $user);
});

// ── Legacy catalog queries (paginated) ───────────────────

const QUERIES = [
    1  => "SELECT DISTINCT p.pid, p.pnome FROM Pezzi p JOIN Catalogo c ON p.pid = c.pid ORDER BY p.pnome",
    2  => "SELECT f.fid, f.fnome FROM Fornitori f WHERE NOT EXISTS (SELECT * FROM Pezzi p WHERE NOT EXISTS (SELECT * FROM Catalogo c WHERE c.fid = f.fid AND c.pid = p.pid)) ORDER BY f.fnome",
    3  => "SELECT f.fid, f.fnome FROM Fornitori f WHERE NOT EXISTS (SELECT * FROM Pezzi p WHERE p.colore = 'rosso' AND NOT EXISTS (SELECT * FROM Catalogo c WHERE c.fid = f.fid AND c.pid = p.pid)) ORDER BY f.fnome",
    4  => "SELECT p.pid, p.pnome FROM Pezzi p JOIN Catalogo c ON p.pid = c.pid JOIN Fornitori f ON f.fid = c.fid WHERE f.fnome = 'Acme' AND NOT EXISTS (SELECT * FROM Catalogo c2 WHERE c2.pid = p.pid AND c2.fid <> f.fid) ORDER BY p.pnome",
    5  => "SELECT DISTINCT c.fid, f.fnome FROM Catalogo c JOIN Fornitori f ON f.fid = c.fid WHERE c.costo > (SELECT AVG(c2.costo) FROM Catalogo c2 WHERE c2.pid = c.pid) ORDER BY f.fnome",
    6  => "SELECT p.pid, f.fid, f.fnome FROM Pezzi p JOIN Catalogo c ON p.pid = c.pid JOIN Fornitori f ON f.fid = c.fid WHERE c.costo = (SELECT MAX(c2.costo) FROM Catalogo c2 WHERE c2.pid = p.pid) ORDER BY p.pid",
    7  => "SELECT f.fid, f.fnome FROM Fornitori f WHERE EXISTS (SELECT * FROM Catalogo c JOIN Pezzi p ON p.pid = c.pid WHERE c.fid = f.fid) AND NOT EXISTS (SELECT * FROM Catalogo c JOIN Pezzi p ON p.pid = c.pid WHERE c.fid = f.fid AND p.colore <> 'rosso') ORDER BY f.fnome",
    8  => "SELECT f.fid, f.fnome FROM Fornitori f WHERE EXISTS (SELECT * FROM Catalogo c JOIN Pezzi p ON p.pid = c.pid WHERE c.fid = f.fid AND p.colore = 'rosso') AND EXISTS (SELECT * FROM Catalogo c JOIN Pezzi p ON p.pid = c.pid WHERE c.fid = f.fid AND p.colore = 'verde') ORDER BY f.fnome",
    9  => "SELECT DISTINCT c.fid, f.fnome FROM Catalogo c JOIN Fornitori f ON f.fid = c.fid JOIN Pezzi p ON p.pid = c.pid WHERE p.colore = 'rosso' OR p.colore = 'verde' ORDER BY f.fnome",
    10 => "SELECT p.pid, p.pnome FROM Pezzi p WHERE p.pid IN (SELECT pid FROM Catalogo GROUP BY pid HAVING COUNT(DISTINCT fid) >= 2) ORDER BY p.pnome",
];

$app->get('/queries/{n}', function (Request $request, Response $response, array $args): Response {
    $n = (int) $args['n'];
    if (!array_key_exists($n, QUERIES)) abort(400, 'Query non valida (1–10)');
    [$page, $pp] = pageParams($request);
    $pdo    = makeDB();
    $inner  = QUERIES[$n];
    $result = paginate($pdo,
        "SELECT COUNT(*) FROM ($inner) AS __sub",
        $inner, [], $page, $pp
    );
    return jsonOk($response, $result);
});

$app->get('/details/{type}/{id}', function (Request $request, Response $response, array $args): Response {
    $pdo  = makeDB();
    $type = $args['type'];
    $id   = (int) $args['id'];
    if (!$id) abort(400, 'id non valido');

    if ($type === 'piece') {
        $piece = qdb($pdo, "SELECT * FROM Pezzi WHERE pid = ?", [$id])[0] ?? null;
        if (!$piece) abort(404, 'Pezzo non trovato');
        $suppliers = qdb($pdo,
            "SELECT f.fid, f.fnome, c.costo FROM Catalogo c JOIN Fornitori f ON f.fid = c.fid WHERE c.pid = ? ORDER BY f.fnome",
            [$id]
        );
        return jsonOk($response, ['piece' => $piece, 'suppliers' => $suppliers]);
    }

    if ($type === 'supplier') {
        $supplier = qdb($pdo, "SELECT * FROM Fornitori WHERE fid = ?", [$id])[0] ?? null;
        if (!$supplier) abort(404, 'Fornitore non trovato');
        $pieces = qdb($pdo,
            "SELECT p.pid, p.pnome, p.colore, c.costo FROM Catalogo c JOIN Pezzi p ON p.pid = c.pid WHERE c.fid = ? ORDER BY p.pnome",
            [$id]
        );
        return jsonOk($response, ['supplier' => $supplier, 'pieces' => $pieces]);
    }

    abort(400, 'Tipo non valido: usare "piece" o "supplier"');
});

// ── Supplier: own catalog ─────────────────────────────────

$app->get('/my-catalog', function (Request $request, Response $response): Response {
    $pdo  = makeDB();
    $user = requireAuth($request, $pdo);
    $fid  = ($user['role'] === 'admin')
        ? (int) ($request->getQueryParams()['fid'] ?? 0)
        : (int) $user['fid'];
    if (!$fid) abort(400, 'fid mancante');
    [$page, $pp] = pageParams($request);
    return jsonOk($response, paginate($pdo,
        "SELECT COUNT(*) FROM Catalogo c JOIN Pezzi p ON p.pid = c.pid WHERE c.fid = ?",
        "SELECT c.pid, p.pnome, p.colore, c.costo FROM Catalogo c JOIN Pezzi p ON p.pid = c.pid WHERE c.fid = ? ORDER BY p.pnome",
        [$fid], $page, $pp
    ));
});

$app->post('/my-catalog', function (Request $request, Response $response): Response {
    $pdo  = makeDB();
    $user = requireAuth($request, $pdo);
    $body = bodyParams($request);
    $fid  = ($user['role'] === 'admin') ? (int) ($body['fid'] ?? $user['fid']) : (int) $user['fid'];
    $pid  = (int)   ($body['pid']   ?? 0);
    $cost = $body['costo'] ?? null;
    if (!$pid || $cost === null) abort(400, 'pid e costo obbligatori');
    try {
        $pdo->prepare("INSERT INTO Catalogo (fid, pid, costo) VALUES (?, ?, ?)")
            ->execute([$fid, $pid, (float) $cost]);
    } catch (\PDOException) {
        abort(409, 'Voce già presente o pid non valido');
    }
    return jsonOk($response, ['message' => 'Aggiunto'], 201);
});

$app->put('/my-catalog/{pid}', function (Request $request, Response $response, array $args): Response {
    $pdo  = makeDB();
    $user = requireAuth($request, $pdo);
    $body = bodyParams($request);
    $fid  = ($user['role'] === 'admin') ? (int) ($body['fid'] ?? $user['fid']) : (int) $user['fid'];
    $pid  = (int) $args['pid'];
    $cost = $body['costo'] ?? null;
    if ($cost === null) abort(400, 'costo obbligatorio');
    $pdo->prepare("UPDATE Catalogo SET costo = ? WHERE fid = ? AND pid = ?")
        ->execute([(float) $cost, $fid, $pid]);
    return jsonOk($response, ['message' => 'Aggiornato']);
});

$app->delete('/my-catalog/{pid}', function (Request $request, Response $response, array $args): Response {
    $pdo  = makeDB();
    $user = requireAuth($request, $pdo);
    $fid  = ($user['role'] === 'admin')
        ? (int) ($request->getQueryParams()['fid'] ?? $user['fid'])
        : (int) $user['fid'];
    $pdo->prepare("DELETE FROM Catalogo WHERE fid = ? AND pid = ?")
        ->execute([$fid, (int) $args['pid']]);
    return jsonOk($response, ['message' => 'Eliminato']);
});

// ── Admin: suppliers ──────────────────────────────────────

$app->get('/admin/suppliers', function (Request $request, Response $response): Response {
    $pdo = makeDB();
    requireAdmin($request, $pdo);
    [$page, $pp] = pageParams($request);
    $search = '%' . ($request->getQueryParams()['search'] ?? '') . '%';
    return jsonOk($response, paginate($pdo,
        "SELECT COUNT(*) FROM Fornitori WHERE fnome LIKE ?",
        "SELECT f.fid, f.fnome, (SELECT COUNT(*) FROM Catalogo c WHERE c.fid = f.fid) AS num_pezzi FROM Fornitori f WHERE f.fnome LIKE ? ORDER BY f.fnome",
        [$search], $page, $pp
    ));
});

$app->post('/admin/suppliers', function (Request $request, Response $response): Response {
    $pdo   = makeDB();
    requireAdmin($request, $pdo);
    $fnome = trim(bodyParams($request)['fnome'] ?? '');
    if (!$fnome) abort(400, 'fnome obbligatorio');
    $pdo->prepare("INSERT INTO Fornitori (fnome) VALUES (?)")->execute([$fnome]);
    return jsonOk($response, ['fid' => (int) $pdo->lastInsertId(), 'message' => 'Fornitore aggiunto'], 201);
});

$app->put('/admin/suppliers/{id}', function (Request $request, Response $response, array $args): Response {
    $pdo   = makeDB();
    requireAdmin($request, $pdo);
    $fnome = trim(bodyParams($request)['fnome'] ?? '');
    if (!$fnome) abort(400, 'fnome obbligatorio');
    $pdo->prepare("UPDATE Fornitori SET fnome = ? WHERE fid = ?")->execute([$fnome, (int) $args['id']]);
    return jsonOk($response, ['message' => 'Aggiornato']);
});

$app->delete('/admin/suppliers/{id}', function (Request $request, Response $response, array $args): Response {
    $pdo = makeDB();
    requireAdmin($request, $pdo);
    $pdo->prepare("DELETE FROM Fornitori WHERE fid = ?")->execute([(int) $args['id']]);
    return jsonOk($response, ['message' => 'Eliminato']);
});

// ── Admin: pieces ─────────────────────────────────────────

$app->get('/admin/pieces', function (Request $request, Response $response): Response {
    $pdo = makeDB();
    requireAdmin($request, $pdo);
    [$page, $pp] = pageParams($request);
    $search = '%' . ($request->getQueryParams()['search'] ?? '') . '%';
    return jsonOk($response, paginate($pdo,
        "SELECT COUNT(*) FROM Pezzi WHERE pnome LIKE ? OR colore LIKE ?",
        "SELECT p.pid, p.pnome, p.colore, (SELECT COUNT(*) FROM Catalogo c WHERE c.pid = p.pid) AS num_fornitori FROM Pezzi p WHERE p.pnome LIKE ? OR p.colore LIKE ? ORDER BY p.pnome",
        [$search, $search], $page, $pp
    ));
});

$app->post('/admin/pieces', function (Request $request, Response $response): Response {
    $pdo   = makeDB();
    requireAdmin($request, $pdo);
    $body  = bodyParams($request);
    $pnome = trim($body['pnome']  ?? '');
    $col   = trim($body['colore'] ?? '');
    if (!$pnome || !$col) abort(400, 'pnome e colore obbligatori');
    $pdo->prepare("INSERT INTO Pezzi (pnome, colore) VALUES (?, ?)")->execute([$pnome, $col]);
    return jsonOk($response, ['pid' => (int) $pdo->lastInsertId(), 'message' => 'Pezzo aggiunto'], 201);
});

$app->put('/admin/pieces/{id}', function (Request $request, Response $response, array $args): Response {
    $pdo   = makeDB();
    requireAdmin($request, $pdo);
    $body  = bodyParams($request);
    $pnome = trim($body['pnome']  ?? '');
    $col   = trim($body['colore'] ?? '');
    if (!$pnome || !$col) abort(400, 'pnome e colore obbligatori');
    $pdo->prepare("UPDATE Pezzi SET pnome = ?, colore = ? WHERE pid = ?")->execute([$pnome, $col, (int) $args['id']]);
    return jsonOk($response, ['message' => 'Aggiornato']);
});

$app->delete('/admin/pieces/{id}', function (Request $request, Response $response, array $args): Response {
    $pdo = makeDB();
    requireAdmin($request, $pdo);
    $pdo->prepare("DELETE FROM Pezzi WHERE pid = ?")->execute([(int) $args['id']]);
    return jsonOk($response, ['message' => 'Eliminato']);
});

// ── Admin: catalog ────────────────────────────────────────

$app->get('/admin/catalog', function (Request $request, Response $response): Response {
    $pdo    = makeDB();
    requireAdmin($request, $pdo);
    [$page, $pp] = pageParams($request);
    $q      = $request->getQueryParams();
    $where  = '1=1'; $params = [];
    if (!empty($q['fid'])) { $where .= ' AND c.fid = ?'; $params[] = (int) $q['fid']; }
    if (!empty($q['pid'])) { $where .= ' AND c.pid = ?'; $params[] = (int) $q['pid']; }
    return jsonOk($response, paginate($pdo,
        "SELECT COUNT(*) FROM Catalogo c WHERE $where",
        "SELECT c.fid, f.fnome, c.pid, p.pnome, p.colore, c.costo FROM Catalogo c JOIN Fornitori f ON f.fid = c.fid JOIN Pezzi p ON p.pid = c.pid WHERE $where ORDER BY f.fnome, p.pnome",
        $params, $page, $pp
    ));
});

$app->post('/admin/catalog', function (Request $request, Response $response): Response {
    $pdo  = makeDB();
    requireAdmin($request, $pdo);
    $body = bodyParams($request);
    $fid  = (int)   ($body['fid']   ?? 0);
    $pid  = (int)   ($body['pid']   ?? 0);
    $cost = $body['costo'] ?? null;
    if (!$fid || !$pid || $cost === null) abort(400, 'fid, pid e costo obbligatori');
    try {
        $pdo->prepare("INSERT INTO Catalogo (fid, pid, costo) VALUES (?, ?, ?)")->execute([$fid, $pid, (float) $cost]);
    } catch (\PDOException) {
        abort(409, 'Voce già presente o chiave non valida');
    }
    return jsonOk($response, ['message' => 'Aggiunto'], 201);
});

$app->put('/admin/catalog/{fid}/{pid}', function (Request $request, Response $response, array $args): Response {
    $pdo  = makeDB();
    requireAdmin($request, $pdo);
    $cost = bodyParams($request)['costo'] ?? null;
    if ($cost === null) abort(400, 'costo obbligatorio');
    $pdo->prepare("UPDATE Catalogo SET costo = ? WHERE fid = ? AND pid = ?")
        ->execute([(float) $cost, (int) $args['fid'], (int) $args['pid']]);
    return jsonOk($response, ['message' => 'Aggiornato']);
});

$app->delete('/admin/catalog/{fid}/{pid}', function (Request $request, Response $response, array $args): Response {
    $pdo = makeDB();
    requireAdmin($request, $pdo);
    $pdo->prepare("DELETE FROM Catalogo WHERE fid = ? AND pid = ?")
        ->execute([(int) $args['fid'], (int) $args['pid']]);
    return jsonOk($response, ['message' => 'Eliminato']);
});

// ── Admin: users ──────────────────────────────────────────

$app->get('/admin/users', function (Request $request, Response $response): Response {
    $pdo = makeDB();
    requireAdmin($request, $pdo);
    [$page, $pp] = pageParams($request);
    return jsonOk($response, paginate($pdo,
        "SELECT COUNT(*) FROM Users",
        "SELECT u.uid, u.username, u.role, u.fid, f.fnome, u.created_at FROM Users u LEFT JOIN Fornitori f ON f.fid = u.fid ORDER BY u.uid",
        [], $page, $pp
    ));
});

$app->post('/admin/users', function (Request $request, Response $response): Response {
    $pdo   = makeDB();
    requireAdmin($request, $pdo);
    $body  = bodyParams($request);
    $uname = trim($body['username'] ?? '');
    $pw    = $body['password'] ?? '';
    $role  = $body['role']     ?? 'supplier';
    $fid   = $body['fid']      ?? null;
    if (!$uname || !$pw) abort(400, 'username e password obbligatori');
    if (!in_array($role, ['admin', 'supplier'], true)) abort(400, 'role non valido');
    try {
        $pdo->prepare("INSERT INTO Users (username, password, role, fid) VALUES (?, ?, ?, ?)")
            ->execute([$uname, password_hash($pw, PASSWORD_BCRYPT), $role, $fid ?: null]);
    } catch (\PDOException) {
        abort(409, 'Username già esistente');
    }
    return jsonOk($response, ['uid' => (int) $pdo->lastInsertId()], 201);
});

$app->put('/admin/users/{id}', function (Request $request, Response $response, array $args): Response {
    $pdo    = makeDB();
    requireAdmin($request, $pdo);
    $body   = bodyParams($request);
    $sets   = []; $params = [];
    if (!empty($body['username']))           { $sets[] = 'username = ?'; $params[] = trim($body['username']); }
    if (!empty($body['password']))           { $sets[] = 'password = ?'; $params[] = password_hash($body['password'], PASSWORD_BCRYPT); }
    if (!empty($body['role']))               { $sets[] = 'role = ?';     $params[] = $body['role']; }
    if (array_key_exists('fid', $body))      { $sets[] = 'fid = ?';      $params[] = $body['fid'] ?: null; }
    if (!$sets) abort(400, 'Nessun campo da aggiornare');
    $params[] = (int) $args['id'];
    $pdo->prepare("UPDATE Users SET " . implode(', ', $sets) . " WHERE uid = ?")->execute($params);
    return jsonOk($response, ['message' => 'Aggiornato']);
});

$app->delete('/admin/users/{id}', function (Request $request, Response $response, array $args): Response {
    $pdo = makeDB();
    requireAdmin($request, $pdo);
    $pdo->prepare("DELETE FROM Users WHERE uid = ?")->execute([(int) $args['id']]);
    return jsonOk($response, ['message' => 'Eliminato']);
});

// ── Run ───────────────────────────────────────────────────
$app->run();
