<?php
// index.php – Catalog query viewer (updated: paginated results + portal links)
?>
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>Catalogo Fornitori</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&family=Fira+Code:wght@400;500&display=swap" rel="stylesheet"/>
<style>
:root {
  --accent: #5ba08e; --accent-light: rgba(91,160,142,0.15);
  --bg: #141718; --surface: #1e2122; --sidebar-bg: #111314; --sidebar-text: #8a9399;
  --sidebar-active: #5ba08e; --border: #2a2e30; --text: #dde3e6; --muted: #606870;
  --danger: #e05c5c; --danger-bg: rgba(224,92,92,0.1);
}
* { box-sizing:border-box; margin:0; padding:0; }
body { font-family:"Nunito", sans-serif; display:flex; min-height:100vh; background:var(--bg); color:var(--text);}
#sidebar { width:270px; background:var(--sidebar-bg); flex-shrink:0; display:flex; flex-direction:column; position:fixed; top:0; left:0; min-height:100vh; z-index:100; transition:transform 0.3s;}
.sidebar-header { padding:20px 24px 16px; border-bottom:1px solid rgba(255,255,255,0.08);}
.sidebar-header h1 { font-size:1.1rem; font-weight:700; color:#fff;}
.sidebar-header p { font-size:0.78rem; color:var(--sidebar-text); margin-top:4px;}
.sidebar-links { padding:10px 14px; border-bottom:1px solid rgba(255,255,255,0.06); display:flex; gap:8px;}
.portal-link { flex:1; display:flex; align-items:center; justify-content:center; gap:5px; padding:7px; border-radius:7px; font-size:0.72rem; font-weight:700; text-decoration:none; transition:opacity .2s;}
.portal-link:hover { opacity:.8;}
.portal-admin { background:rgba(255,107,53,.15); color:#ff9d6b;}
.portal-supplier { background:rgba(91,160,142,.15); color:var(--accent);}
.nav-section { padding:10px 24px 4px; font-size:.65rem; font-weight:700; letter-spacing:.1em; color:var(--muted); text-transform:uppercase;}
.nav-list { list-style:none; padding:6px 0; flex:1; overflow-y:auto;}
.nav-list li a { display:flex; align-items:center; gap:12px; padding:9px 24px; color:var(--sidebar-text); text-decoration:none; font-size:0.88rem; font-weight:600; border-left:3px solid transparent; transition: all 0.2s;}
.nav-list li a:hover { color:#fff; background:rgba(255,255,255,0.06);}
.nav-list li a.active { color:var(--sidebar-active); border-left-color:var(--sidebar-active); background: rgba(129,199,184,0.1);}
.nav-list li a .num { font-family:"Fira Code", monospace; font-size:0.7rem; background:rgba(255,255,255,0.1); border-radius:4px; padding:2px 6px; min-width:30px; text-align:center; flex-shrink:0;}
.nav-list li a.active .num { background:var(--sidebar-active); color:var(--sidebar-bg);}
#main { margin-left:270px; flex:1; padding:40px 48px 80px; min-height:100vh; animation:fadeIn 0.2s ease;}
.section-header { margin-bottom:24px;}
.section-header .tag { font-family:"Fira Code", monospace; font-size:0.72rem; color:var(--accent); text-transform:uppercase; letter-spacing:0.1em; background:var(--accent-light); display:inline-block; padding:3px 10px; border-radius:20px; margin-bottom:8px;}
.section-header h2 { font-size:1.7rem; font-weight:700; margin-bottom:6px; color:var(--text); line-height:1.3;}
.section-header p { color:var(--muted); font-size:0.93rem; max-width:600px; line-height:1.6;}
.sql-block { background:#0e1a24; border-radius:8px; padding:16px 20px; font-family:"Fira Code", monospace; font-size:0.8rem; color:#a8d8c8; margin-bottom:20px; overflow-x:auto; white-space:pre; line-height:1.8;}
.btn-fetch { font-family:"Nunito", sans-serif; font-size:0.9rem; font-weight:700; background:var(--accent); color:#fff; border:none; border-radius:8px; padding:10px 28px; cursor:pointer; transition: background 0.2s, transform 0.1s;}
.btn-fetch:hover { background:#3a6459;}
.btn-fetch:active { transform:scale(0.98);}
.btn-fetch:disabled { opacity:0.5; cursor:not-allowed;}
.result-area { margin-top:24px;}
.result-meta { font-size:0.8rem; color:var(--muted); margin-bottom:10px; font-family:"Fira Code", monospace; display:flex; align-items:center; justify-content:space-between;}
.result-meta span { color:var(--accent); font-weight:600;}
.table-wrapper { border:1px solid var(--border); border-radius:8px; overflow:hidden; background:var(--surface);}
table { width:100%; border-collapse:collapse;}
thead tr { background:#252a2c; border-bottom:1px solid var(--border);}
thead th { padding:12px 16px; font-size:0.78rem; text-transform:uppercase; letter-spacing:0.06em; color:var(--muted); font-weight:700; text-align:left;}
tbody tr { border-bottom:1px solid var(--border); transition: background 0.15s;}
tbody tr:last-child { border-bottom:none;}
tbody tr:hover { background: rgba(91,160,142,0.05);}
tbody td { padding:11px 16px; font-size:0.9rem; color:var(--text);}
.empty-state { padding:48px; text-align:center; color:var(--muted); font-size:0.9rem; background:var(--surface); border-radius:8px; border:1px solid var(--border);}
.error-state { padding:16px 20px; background:var(--danger-bg); border:1px solid rgba(224,92,92,0.3); border-radius:8px; color:var(--danger); font-size:0.85rem;}
/* Pagination */
.pagination-bar { display:flex; align-items:center; gap:6px; padding:14px 16px; border-top:1px solid var(--border); background:#1a1e20;}
.pagination-bar .pinfo { font-size:.75rem; color:var(--muted); flex:1; font-family:"Fira Code",monospace;}
.page-btn { background:rgba(255,255,255,.07); border:none; color:var(--muted); padding:5px 10px; border-radius:5px; cursor:pointer; font-family:"Fira Code",monospace; font-size:.72rem; transition:all .15s;}
.page-btn:hover { color:var(--text); background:rgba(255,255,255,.12);}
.page-btn.active { background:var(--accent); color:#fff;}
.page-btn:disabled { opacity:.3; cursor:not-allowed;}
/* Modal */
.modal-content { background:var(--surface); border:1px solid var(--border); color:var(--text);}
.modal-header { border-bottom:1px solid var(--border); background:rgba(91,160,142,0.1);}
.modal-title { color:var(--text); font-weight:700;}
.modal-body { padding:24px; color:var(--text);}
.modal-body h6 { color:var(--accent); font-weight:700; margin-top:16px; margin-bottom:8px;}
.modal-body h6:first-child { margin-top:0;}
.modal-body p { color:var(--text); margin:6px 0; font-size:0.95rem;}
.modal-body ul { list-style:none; padding:0; margin:8px 0 0 0;}
.modal-body li { padding:8px 12px; margin:4px 0; background:rgba(91,160,142,0.05); border-left:3px solid var(--accent); border-radius:4px; color:var(--text); font-size:0.9rem; display:flex; justify-content:space-between;}
.modal-body .cost { font-family:"Fira Code",monospace; color:var(--accent); font-size:.8rem;}
.btn-close { filter:invert(1) brightness(0.95);}
.spinner { display:inline-block; width:14px; height:14px; border:2px solid rgba(255,255,255,0.3); border-top-color:#fff; border-radius:50%; animation:spin 0.7s linear infinite; vertical-align:middle; margin-right:6px;}
@keyframes spin { to { transform:rotate(360deg); } }
@keyframes fadeIn { from { opacity:0; transform:translateY(6px); } to { opacity:1; transform:translateY(0); } }
#menu-toggle { display:none; position:fixed; top:16px; left:16px; z-index:200; background:var(--accent); color:#fff; border:none; border-radius:6px; padding:8px 12px; font-size:1.1rem; cursor:pointer;}
@media (max-width:768px){#sidebar{transform:translateX(-100%);}#sidebar.open{transform:translateX(0);}#main{margin-left:0;padding:24px 16px 60px;padding-top:70px;}#menu-toggle{display:block;}}
</style>
</head>
<body>
<button id="menu-toggle" onclick="document.getElementById('sidebar').classList.toggle('open')">☰</button>
<nav id="sidebar">
  <div class="sidebar-header"><h1>Catalogo DB</h1><p>10 query analitiche</p></div>
  <div class="sidebar-links">
    <a class="portal-link portal-admin" href="admin.php">🔐 Admin</a>
    <a class="portal-link portal-supplier" href="supplier.php">🏭 Fornitore</a>
  </div>
  <div class="nav-section">Query</div>
  <ul class="nav-list">
    <?php
    $queriesNav = [
      'q1' =>['label'=>'Pezzi con fornitori',     'num'=>'01','api'=>1],
      'q2' =>['label'=>'Fornitori con tutti i pezzi','num'=>'02','api'=>2],
      'q3' =>['label'=>'Fornitori pezzi rossi',    'num'=>'03','api'=>3],
      'q4' =>['label'=>'Pezzi solo Acme',          'num'=>'04','api'=>4],
      'q5' =>['label'=>'Fornitori sopra media',    'num'=>'05','api'=>5],
      'q6' =>['label'=>'Fornitori max ricarico',   'num'=>'06','api'=>6],
      'q7' =>['label'=>'Fornitori solo rossi',     'num'=>'07','api'=>7],
      'q8' =>['label'=>'Fornitori rosso e verde',  'num'=>'08','api'=>8],
      'q9' =>['label'=>'Fornitori rosso o verde',  'num'=>'09','api'=>9],
      'q10'=>['label'=>'Pezzi almeno 2 fornitori', 'num'=>'10','api'=>10],
    ];
    foreach($queriesNav as $id=>$q){
        $active = ($id==='q1') ? 'active' : '';
        echo "<li><a href='#' class='$active' onclick=\"selectQuery('$id',{$q['api']});return false;\"><span class='num'>{$q['num']}</span> {$q['label']}</a></li>";
    }
    ?>
  </ul>
</nav>
<main id="main">
  <div id="page-content">
    <div class="section-header"><div class="tag">Query 01</div><h2>Pezzi con fornitori</h2><p>Restituisce i nomi dei pezzi che hanno almeno un fornitore nel catalogo.</p></div>
    <div class="sql-block">SELECT DISTINCT p.pid, p.pnome
FROM Pezzi p
JOIN Catalogo c ON p.pid = c.pid</div>
    <button class="btn-fetch" id="btn-fetch" onclick="fetchData(1,1)">▶ Esegui Query</button>
    <div class="result-area" id="result"></div>
  </div>
</main>

<!-- Modal -->
<div class="modal fade" id="detailsModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="detailsModalLabel">Dettagli</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" id="modal-body">Caricamento...</div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
let currentApiNum = 1;
let currentPage   = 1;

const queryDefs = {
  1:  ["Pezzi con fornitori",
       `SELECT DISTINCT p.pid, p.pnome\nFROM Pezzi p\nJOIN Catalogo c ON p.pid = c.pid`,
       "Restituisce i nomi dei pezzi che hanno almeno un fornitore nel catalogo."],
  2:  ["Fornitori con tutti i pezzi",
       `SELECT f.fid, f.fnome\nFROM Fornitori f\nWHERE NOT EXISTS (\n    SELECT * FROM Pezzi p\n    WHERE NOT EXISTS (\n        SELECT * FROM Catalogo c WHERE c.fid = f.fid AND c.pid = p.pid\n    )\n)`,
       "Fornitori che forniscono ogni pezzo presente nel catalogo."],
  3:  ["Fornitori pezzi rossi",
       `SELECT f.fid, f.fnome\nFROM Fornitori f\nWHERE NOT EXISTS (\n    SELECT * FROM Pezzi p WHERE p.colore = 'rosso'\n    AND NOT EXISTS (\n        SELECT * FROM Catalogo c WHERE c.fid = f.fid AND c.pid = p.pid\n    )\n)`,
       "Fornitori che forniscono almeno tutti i pezzi di colore rosso."],
  4:  ["Pezzi solo Acme",
       `SELECT p.pid, p.pnome\nFROM Pezzi p JOIN Catalogo c ON p.pid = c.pid\nJOIN Fornitori f ON f.fid = c.fid\nWHERE f.fnome = 'Acme'\nAND NOT EXISTS (\n    SELECT * FROM Catalogo c2 WHERE c2.pid = p.pid AND c2.fid <> f.fid\n)`,
       "Pezzi forniti esclusivamente dal fornitore Acme."],
  5:  ["Fornitori sopra media",
       `SELECT DISTINCT c.fid, f.fnome\nFROM Catalogo c JOIN Fornitori f ON f.fid = c.fid\nWHERE c.costo > (SELECT AVG(c2.costo) FROM Catalogo c2 WHERE c2.pid = c.pid)`,
       "Fornitori con almeno un pezzo con costo superiore alla media."],
  6:  ["Fornitori max ricarico",
       `SELECT p.pid, f.fid, f.fnome\nFROM Pezzi p JOIN Catalogo c ON p.pid = c.pid\nJOIN Fornitori f ON f.fid = c.fid\nWHERE c.costo = (SELECT MAX(c2.costo) FROM Catalogo c2 WHERE c2.pid = p.pid)`,
       "Per ogni pezzo, il fornitore che lo vende al prezzo più alto."],
  7:  ["Fornitori solo rossi",
       `SELECT f.fid, f.fnome FROM Fornitori f\nWHERE EXISTS (SELECT * FROM Catalogo c JOIN Pezzi p ON p.pid=c.pid WHERE c.fid=f.fid)\nAND NOT EXISTS (SELECT * FROM Catalogo c JOIN Pezzi p ON p.pid=c.pid WHERE c.fid=f.fid AND p.colore<>'rosso')`,
       "Fornitori il cui catalogo contiene esclusivamente pezzi rossi."],
  8:  ["Fornitori rosso e verde",
       `SELECT f.fid, f.fnome FROM Fornitori f\nWHERE EXISTS (SELECT * FROM Catalogo c JOIN Pezzi p ON p.pid=c.pid WHERE c.fid=f.fid AND p.colore='rosso')\nAND EXISTS (SELECT * FROM Catalogo c JOIN Pezzi p ON p.pid=c.pid WHERE c.fid=f.fid AND p.colore='verde')`,
       "Fornitori con almeno un pezzo rosso e almeno uno verde."],
  9:  ["Fornitori rosso o verde",
       `SELECT DISTINCT c.fid, f.fnome FROM Catalogo c\nJOIN Fornitori f ON f.fid=c.fid JOIN Pezzi p ON p.pid=c.pid\nWHERE p.colore='rosso' OR p.colore='verde'`,
       "Fornitori con almeno un pezzo rosso oppure verde."],
  10: ["Pezzi almeno 2 fornitori",
       `SELECT p.pid, p.pnome FROM Pezzi p\nWHERE p.pid IN (\n    SELECT pid FROM Catalogo GROUP BY pid HAVING COUNT(DISTINCT fid) >= 2\n)`,
       "Pezzi presenti nel catalogo di almeno due fornitori distinti."],
};

function selectQuery(id, apiNum){
  currentApiNum = apiNum;
  currentPage   = 1;
  document.querySelectorAll('.nav-list li a').forEach(a=>a.classList.remove('active'));
  event.target.closest('a').classList.add('active');
  const q = queryDefs[apiNum];
  document.getElementById('page-content').innerHTML =
    `<div class="section-header">
       <div class="tag">Query ${String(apiNum).padStart(2,'0')}</div>
       <h2>${q[0]}</h2><p>${q[2]}</p>
     </div>
     <div class="sql-block">${q[1]}</div>
     <button class="btn-fetch" id="btn-fetch" onclick="fetchData(${apiNum},1)">▶ Esegui Query</button>
     <div class="result-area" id="result"></div>`;
}

async function fetchData(apiNum, page=1){
  currentPage = page;
  const btn = document.getElementById('btn-fetch');
  const resultDiv = document.getElementById('result');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span> Caricamento...';
  resultDiv.innerHTML = '';
  try {
    const res = await fetch(`/api.php?query=${apiNum}&page=${page}&per_page=15`);
    if(!res.ok) throw new Error('HTTP '+res.status);
    const d = await res.json();
    if(!d.ok) throw new Error(d.error||'Errore sconosciuto');
    renderTable(resultDiv, d.data, apiNum);
  } catch(err){
    resultDiv.innerHTML = '<div class="error-state">⚠ Errore: '+err.message+'</div>';
  } finally {
    btn.disabled = false;
    btn.innerHTML = '▶ Esegui Query';
  }
}

function renderTable(container, data, apiNum){
  const {items,total,page,pages,per_page} = data;
  if(!items||items.length===0){
    container.innerHTML='<div class="empty-state">Nessun risultato trovato.</div>'; return;
  }
  const cols = Object.keys(items[0]);
  let html  = `<div class="result-meta"><div>Risultati: <span>${total}</span> righe — pagina <span>${page}/${pages}</span></div></div>`;
  html += '<div class="table-wrapper"><table><thead><tr>';
  cols.forEach(c=>html+=`<th>${c}</th>`);
  html += '</tr></thead><tbody>';
  items.forEach(row=>{
    const type = row.pid  ? 'piece'    : 'supplier';
    const id   = row.pid  || row.fid;
    html += `<tr onclick="showDetails('${type}',${id})" style="cursor:pointer">`;
    cols.forEach(c=>html+=`<td>${row[c]!==null?row[c]:'—'}</td>`);
    html += '</tr>';
  });
  html += '</tbody></table>';
  // pagination
  if(pages>1){
    html += '<div class="pagination-bar">';
    html += `<div class="pinfo">${total} righe · ${per_page}/pag</div>`;
    html += `<button class="page-btn" onclick="fetchData(${apiNum},${page-1})" ${page<=1?'disabled':''}>‹</button>`;
    for(let i=Math.max(1,page-2);i<=Math.min(pages,page+2);i++)
      html+=`<button class="page-btn ${i===page?'active':''}" onclick="fetchData(${apiNum},${i})">${i}</button>`;
    html += `<button class="page-btn" onclick="fetchData(${apiNum},${page+1})" ${page>=pages?'disabled':''}>›</button>`;
    html += '</div>';
  }
  html += '</div>';
  container.innerHTML = html;
}

async function showDetails(type, id) {
  const modal = new bootstrap.Modal(document.getElementById('detailsModal'));
  const body  = document.getElementById('modal-body');
  body.innerHTML = '<span class="spinner"></span> Caricamento...';
  modal.show();
  try {
    const res = await fetch(`/api.php?details=${type}&id=${id}`);
    if(!res.ok) throw new Error('HTTP '+res.status);
    const d = await res.json();
    if(!d.ok) throw new Error(d.error);
    const data = d.data;
    let html = '';
    if(type==='piece'){
      html += `<h6>Pezzo</h6>
               <p>ID: <strong>${data.piece.pid}</strong></p>
               <p>Nome: <strong>${data.piece.pnome}</strong></p>
               <p>Colore: <strong>${data.piece.colore}</strong></p>
               <h6>Fornitori (${data.suppliers.length})</h6><ul>`;
      data.suppliers.forEach(s=>{ html+=`<li><span>${s.fnome}</span><span class="cost">€${s.costo}</span></li>`; });
      html += '</ul>';
    } else {
      html += `<h6>Fornitore</h6>
               <p>ID: <strong>${data.supplier.fid}</strong></p>
               <p>Nome: <strong>${data.supplier.fnome}</strong></p>
               <h6>Pezzi forniti (${data.pieces.length})</h6><ul>`;
      data.pieces.forEach(p=>{ html+=`<li><span>${p.pnome} (${p.colore})</span><span class="cost">€${p.costo}</span></li>`; });
      html += '</ul>';
    }
    body.innerHTML = html;
  } catch(err){ body.innerHTML = '⚠ Errore: '+err.message; }
}
</script>
</body>
</html>
