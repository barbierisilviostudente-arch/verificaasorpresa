-- ============================================================
-- Schema: verificaasorpresa  (extended with auth + roles)
-- ============================================================

CREATE DATABASE IF NOT EXISTS verificaasorpresa CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE verificaasorpresa;

-- ------------------------------------------------------------
-- Core domain tables
-- ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Fornitori (
    fid   INT AUTO_INCREMENT PRIMARY KEY,
    fnome VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Pezzi (
    pid    INT AUTO_INCREMENT PRIMARY KEY,
    pnome  VARCHAR(100) NOT NULL,
    colore VARCHAR(50)  NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Catalogo (
    fid   INT NOT NULL,
    pid   INT NOT NULL,
    costo DECIMAL(10,2) NOT NULL,
    PRIMARY KEY (fid, pid),
    FOREIGN KEY (fid) REFERENCES Fornitori(fid) ON DELETE CASCADE,
    FOREIGN KEY (pid) REFERENCES Pezzi(pid)     ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Users table  (role: 'admin' | 'supplier')
-- Suppliers are linked to a Fornitori row
-- ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Users (
    uid       INT AUTO_INCREMENT PRIMARY KEY,
    username  VARCHAR(80)  NOT NULL UNIQUE,
    password  VARCHAR(255) NOT NULL,          -- bcrypt hash
    role      ENUM('admin','supplier') NOT NULL DEFAULT 'supplier',
    fid       INT DEFAULT NULL,               -- only for role='supplier'
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (fid) REFERENCES Fornitori(fid) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Sessions table
-- ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Sessions (
    token      CHAR(64)    PRIMARY KEY,
    uid        INT         NOT NULL,
    expires_at DATETIME    NOT NULL,
    FOREIGN KEY (uid) REFERENCES Users(uid) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Sample data
-- ------------------------------------------------------------

INSERT IGNORE INTO Fornitori (fid, fnome) VALUES
  (1,'Acme'),(2,'Globex'),(3,'Initech'),(4,'Umbrella'),(5,'Soylent');

INSERT IGNORE INTO Pezzi (pid, pnome, colore) VALUES
  (1,'Bullone M8','rosso'),(2,'Vite M6','verde'),(3,'Rondella','blu'),
  (4,'Dado M10','rosso'),(5,'Piastra','verde'),(6,'Molla','giallo');

INSERT IGNORE INTO Catalogo (fid,pid,costo) VALUES
  (1,1,1.20),(1,2,0.80),(1,3,0.50),(1,4,1.50),
  (2,1,1.10),(2,3,0.45),(2,5,2.00),
  (3,2,0.90),(3,4,1.40),(3,6,3.50),
  (4,1,1.30),(4,2,0.75),(4,5,1.90),(4,6,3.00),
  (5,3,0.40),(5,4,1.60),(5,5,2.10);

-- Passwords are bcrypt of 'admin123' and 'supplier123'
-- You can regenerate with: php -r "echo password_hash('admin123', PASSWORD_BCRYPT);"
INSERT IGNORE INTO Users (uid, username, password, role, fid) VALUES
  (1, 'admin',   '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin',    NULL),
  (2, 'acme',    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'supplier', 1),
  (3, 'globex',  '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'supplier', 2),
  (4, 'initech', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'supplier', 3);

-- NOTE: all sample passwords = "password" (bcrypt hash above)
-- Change immediately in production!
