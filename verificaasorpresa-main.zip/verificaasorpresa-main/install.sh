#!/bin/bash

# Uscita immediata se un comando fallisce
set -e

# CONFIGURA QUI IL TUO UTENTE E PASSWORD
PMA_USER="a"
PMA_PASS="a"
BLOWFISH_SECRET="qwertyuiopasdfghjklzxcvbnmqwerty"

# ensure repository list is clean and keys are present
# some containers include the Yarn APT source which can be unsigned
if [ -f /etc/apt/sources.list.d/yarn.list ]; then
    echo "⚠️  Removing unsigned Yarn APT repository to avoid errors..."
    sudo rm -f /etc/apt/sources.list.d/yarn.list
fi

# add Yarn GPG key in case the repo is later needed
echo "🔐 Adding Yarn GPG key (harmless if already present)"
sudo curl -sS https://dl.yarnpkg.com/debian/pubkey.gpg | sudo apt-key add -

echo "🛠️  Aggiornamento pacchetti e installazione Apache, PHP, MariaDB..."
sudo apt update
sudo apt install -y apache2 php libapache2-mod-php php-mysql mariadb-server wget unzip curl

echo "⚡ Installazione PDO MySQL tramite script esterno..."
curl -L https://gist.githubusercontent.com/GitHub30/2d51bfa327a6eddbde33b77214511584/raw/install_pdo_mysql.gh-codespaces.sh | sudo bash

echo "🚀 Avvio di MariaDB..."
sudo service mariadb start

echo "🔒 Esecuzione configurazione sicura MariaDB (automatica con expect)..."
sudo mariadb <<EOF
DELETE FROM mysql.user WHERE User='';
DROP DATABASE IF EXISTS test;
DELETE FROM mysql.db WHERE Db='test' OR Db='test\\_%';
FLUSH PRIVILEGES;
EOF

echo "📂 Installazione phpMyAdmin..."
cd /var/www/html
sudo wget https://www.phpmyadmin.net/downloads/phpMyAdmin-latest-all-languages.zip
sudo unzip phpMyAdmin-latest-all-languages.zip
sudo mv phpMyAdmin-*-all-languages phpmyadmin
sudo rm phpMyAdmin-latest-all-languages.zip

echo "⚙️  Configurazione phpMyAdmin..."
cd phpmyadmin
sudo cp config.sample.inc.php config.inc.php
sudo sed -i "s/\(\$cfg\['blowfish_secret'\] = \).*/\1'$BLOWFISH_SECRET';/" config.inc.php

echo "🌐 Configurazione Apache per phpMyAdmin..."
cat <<EOCONF | sudo tee /etc/apache2/conf-available/phpmyadmin.conf
Alias /phpmyadmin /var/www/html/phpmyadmin

<Directory /var/www/html/phpmyadmin>
    Options Indexes FollowSymLinks
    DirectoryIndex index.php
    AllowOverride All
    Require all granted
</Directory>
EOCONF

sudo a2enconf phpmyadmin
sudo service apache2 restart

echo "👤 Creazione utente MariaDB per phpMyAdmin..."
sudo mariadb <<EOF
CREATE USER IF NOT EXISTS '$PMA_USER'@'localhost' IDENTIFIED BY '$PMA_PASS';
GRANT ALL PRIVILEGES ON *.* TO '$PMA_USER'@'localhost' WITH GRANT OPTION;
FLUSH PRIVILEGES;
EOF

echo ""
echo "✅ Installazione completata!"
echo "🔗 Accedi a phpMyAdmin all'indirizzo:"
echo "    http://localhost/phpmyadmin"
echo ""
echo "👤 Credenziali di accesso:"
echo "    Utente: $PMA_USER"
echo "    Password: $PMA_PASS"